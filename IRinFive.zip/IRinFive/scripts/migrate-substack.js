/**
 * IRinFive - Simplified Substack Migration Script
 * 
 * This script helps migrate content from Substack to a Next.js site
 * It focuses on:
 * 1. Processing exported Substack posts
 * 2. Extracting and downloading images to the public folder
 * 3. Converting HTML to Markdown
 * 4. Exporting subscribers for ConvertKit import
 * 
 * Usage:
 * 1. Extract Substack export ZIP to ./substack-export/
 * 2. Run: node scripts/migrate-substack.js
 */

const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');
const TurndownService = require('turndown');
const https = require('https');
const csv = require('csv-parser');

// Configuration
const CONFIG = {
  // Directories
  substackDir: './substack-export/posts',
  subscribersFile: './substack-export/subscribers.csv',
  outputPostsDir: './content/posts',
  outputImagesDir: './public/images/posts', // For Next.js public folder
  
  // Settings
  downloadImages: true,
  convertToMarkdown: true,
  processSubscribers: true,
  
  // Optional custom mappings for categories/topics
  topicMappings: {
    'politics': 'Politics',
    'security': 'Security',
    'technology': 'Technology',
    'international-relations': 'International Relations',
    'climate': 'Climate',
    'cyber': 'Cybersecurity'
  }
};

// Initialize turndown for HTML to Markdown conversion
const turndownService = new TurndownService({
  headingStyle: 'atx',
  codeBlockStyle: 'fenced',
  emDelimiter: '*'
});

// Add custom rules for Substack-specific content
turndownService.addRule('subscriptRule', {
  filter: ['sub'],
  replacement: function(content) {
    return `<sub>${content}</sub>`;
  }
});

turndownService.addRule('superscriptRule', {
  filter: ['sup'],
  replacement: function(content) {
    return `<sup>${content}</sup>`;
  }
});

// Main execution
async function main() {
  try {
    console.log('Starting Substack migration for Next.js...');
    
    // Create output directories if they don't exist
    ensureDirectoriesExist();
    
    // Process posts
    if (fs.existsSync(CONFIG.substackDir)) {
      console.log('Processing Substack posts...');
      await processSubstackPosts();
    } else {
      console.error(`Error: Substack posts directory not found at ${CONFIG.substackDir}`);
      console.log('Please extract your Substack export to ./substack-export/');
    }
    
    // Process subscribers
    if (CONFIG.processSubscribers && fs.existsSync(CONFIG.subscribersFile)) {
      console.log('Processing subscribers...');
      await processSubstackSubscribers();
    } else if (CONFIG.processSubscribers) {
      console.error(`Error: Subscribers file not found at ${CONFIG.subscribersFile}`);
    }
    
    console.log('Migration completed!');
  } catch (error) {
    console.error('Migration failed:', error);
  }
}

// Ensure output directories exist
function ensureDirectoriesExist() {
  const dirs = [CONFIG.outputPostsDir, CONFIG.outputImagesDir];
  
  dirs.forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log(`Created directory: ${dir}`);
    }
  });
}

// Process Substack posts
async function processSubstackPosts() {
  // Get all HTML files
  const files = fs.readdirSync(CONFIG.substackDir).filter(file => file.endsWith('.html'));
  
  console.log(`Found ${files.length} posts to process`);
  
  // Process each file
  for (const file of files) {
    const filePath = path.join(CONFIG.substackDir, file);
    
    try {
      // Read file content
      const html = fs.readFileSync(filePath, 'utf8');
      
      // Extract post data
      const postData = extractPostData(html, file);
      
      // Download images if enabled
      if (CONFIG.downloadImages) {
        await downloadPostImages(postData);
      }
      
      // Convert to Markdown and save
      if (CONFIG.convertToMarkdown) {
        saveAsMarkdown(postData);
      }
      
      console.log(`Processed: ${postData.title}`);
    } catch (error) {
      console.error(`Error processing ${file}:`, error);
    }
  }
}

// Extract post data from HTML
function extractPostData(html, fileName) {
  const $ = cheerio.load(html);
  
  // Basic post data
  const title = $('h1').first().text().trim();
  const subtitle = $('h3').first().text().trim();
  const publishedRaw = $('time').attr('datetime') || new Date().toISOString();
  const published = new Date(publishedRaw).toISOString().split('T')[0];
  
  // Extract slug from filename or generate from title
  const slug = path.basename(fileName, '.html').replace(/\.export$/, '') || 
               title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  
  // Get content
  const contentElement = $('.body');
  let content = contentElement.html() || '';
  
  // Extract images
  const images = [];
  contentElement.find('img').each((i, img) => {
    const imgSrc = $(img).attr('src');
    if (imgSrc) {
      const imgName = `${slug}-${i}-${path.basename(imgSrc).split('?')[0]}`; // Add slug prefix for uniqueness
      images.push({
        src: imgSrc,
        name: imgName,
        localPath: path.join(CONFIG.outputImagesDir, imgName)
      });
      
      // Update image path in content for local reference
      content = content.replace(imgSrc, `/images/posts/${imgName}`); // Path for Next.js public folder
    }
  });
  
  // Extract cover image if available
  let coverImage = null;
  const firstImage = contentElement.find('img').first();
  if (firstImage.length) {
    const imgSrc = firstImage.attr('src');
    if (imgSrc) {
      const imgName = `${slug}-cover-${path.basename(imgSrc).split('?')[0]}`;
      coverImage = `/images/posts/${imgName}`;
      
      // Add to images array if not already included
      const isAlreadyIncluded = images.some(img => img.src === imgSrc);
      if (!isAlreadyIncluded) {
        images.push({
          src: imgSrc,
          name: imgName,
          localPath: path.join(CONFIG.outputImagesDir, imgName)
        });
      }
    }
  }
  
  // Try to extract topics/categories
  const topics = [];
  // Look for category-like elements
  $('.subtitle, .meta, .tags').find('a').each((i, a) => {
    const text = $(a).text().trim();
    if (text && !topics.includes(text)) {
      // Map to custom topic if defined
      const mappedTopic = CONFIG.topicMappings[text.toLowerCase()] || text;
      topics.push(mappedTopic);
    }
  });
  
  // Estimate reading time (rough calculation)
  const textContent = contentElement.text();
  const wordCount = textContent.split(/\s+/).length;
  const readingTime = Math.max(1, Math.ceil(wordCount / 200)); // Assumes 200 WPM reading speed
  
  // Extract author information
  const authorName = $('.byline-name').text().trim() || 'IRinFive Team';
  
  return {
    title,
    subtitle,
    date: published,
    slug,
    content,
    images,
    coverImage,
    topics,
    readingTime,
    wordCount,
    author: authorName,
    excerpt: textContent.substring(0, 160) + '...' // Add a short excerpt for meta descriptions
  };
}

// Download images from a post
async function downloadPostImages(postData) {
  for (const image of postData.images) {
    try {
      // Skip if file already exists
      if (fs.existsSync(image.localPath)) {
        console.log(`Image already exists: ${image.name}`);
        continue;
      }
      
      // Download image
      await downloadFile(image.src, image.localPath);
      console.log(`Downloaded image: ${image.name}`);
    } catch (error) {
      console.error(`Error downloading image ${image.src}:`, error);
    }
  }
}

// Download a file from URL
function downloadFile(url, outputPath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(outputPath);
    
    https.get(url, response => {
      response.pipe(file);
      
      file.on('finish', () => {
        file.close(resolve);
      });
      
      file.on('error', err => {
        fs.unlink(outputPath, () => {});
        reject(err);
      });
    }).on('error', err => {
      fs.unlink(outputPath, () => {});
      reject(err);
    });
  });
}

// Save post as Markdown
function saveAsMarkdown(postData) {
  // Convert HTML to Markdown
  const markdown = turndownService.turndown(postData.content);
  
  // Create frontmatter for Next.js
  const frontmatter = `---
title: "${postData.title.replace(/"/g, '\\"')}"
subtitle: "${(postData.subtitle || '').replace(/"/g, '\\"')}"
date: "${postData.date}"
slug: "${postData.slug}"
${postData.coverImage ? `coverImage: "${postData.coverImage}"` : ''}
topics: [${postData.topics.map(t => `"${t}"`).join(', ')}]
readingTime: ${postData.readingTime}
author: "${postData.author}"
excerpt: "${postData.excerpt.replace(/"/g, '\\"')}"
---

`;
  
  // Combine frontmatter and markdown content
  const fullMarkdown = frontmatter + markdown;
  
  // Write to file
  const outputPath = path.join(CONFIG.outputPostsDir, `${postData.slug}.md`);
  fs.writeFileSync(outputPath, fullMarkdown);
  
  console.log(`Saved markdown file: ${postData.slug}.md`);
}

// Process Substack subscribers
async function processSubstackSubscribers() {
  const subscribers = [];
  
  return new Promise((resolve, reject) => {
    fs.createReadStream(CONFIG.subscribersFile)
      .pipe(csv())
      .on('data', (row) => {
        // Extract subscriber data
        const subscriber = {
          email: row.email,
          name: row.name || '',
          subscribeDate: row.subscribe_date || new Date().toISOString(),
          status: row.status || 'active'
        };
        
        subscribers.push(subscriber);
      })
      .on('end', () => {
        console.log(`Processed ${subscribers.length} subscribers`);
        
        // Save subscribers to JSON for reference
        const outputPath = path.join('./content', 'subscribers.json');
        fs.writeFileSync(outputPath, JSON.stringify(subscribers, null, 2));
        console.log(`Saved subscribers to ${outputPath}`);
        
        // Create ConvertKit-ready CSV
        createConvertKitCsv(subscribers);
        
        resolve();
      })
      .on('error', (error) => {
        reject(error);
      });
  });
}

// Format subscribers for ConvertKit CSV import
function createConvertKitCsv(subscribers) {
  // ConvertKit expects: email,first_name format
  let csvContent = 'email,first_name\n';
  
  subscribers.forEach(sub => {
    // Only include active subscribers
    if (sub.status.toLowerCase() === 'active') {
      // Extract first name from full name
      const firstName = sub.name.split(' ')[0] || '';
      csvContent += `${sub.email},${firstName}\n`;
    }
  });
  
  const outputPath = path.join('./content', 'convertkit-import.csv');
  fs.writeFileSync(outputPath, csvContent);
  
  console.log(`Saved ConvertKit import file to ${outputPath}`);
}

// Run the script
main();