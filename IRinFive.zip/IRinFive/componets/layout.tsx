// components/layout.tsx
import Head from 'next/head';
import Link from 'next/link';

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Head>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <header className="header">
        <div className="container">
          <Link href="/" className="logo">
            IRinFive
          </Link>
          <nav>
            <Link href="/">Home</Link>
            <Link href="/about">About</Link>
            <Link href="/archive">Archive</Link>
          </nav>
        </div>
      </header>

      <main>{children}</main>

      <footer className="footer">
        <div className="container">
          <p>&copy; {new Date().getFullYear()} IRinFive. All rights reserved.</p>
        </div>
      </footer>
    </>
  );
}