/**
 * Irinfive - Notes JavaScript
 * Handles notes functionality (creation, listing, interactions)
 */

// Sample note data (this will come from your API in production)
const SAMPLE_NOTES = [
    {
        id: 'note1',
        content: 'Recent developments in quantum computing could significantly impact encryption standards used for securing diplomatic communications. The race is on to develop quantum-resistant encryption methods.',
        authorName: 'Dr. Jane Smith',
        authorImage: 'images/placeholder.jpg',
        date: '2025-03-04',
        likes: 14,
        comments: 3,
        hasImage: false
    },
    {
        id: 'note2',
        content: 'The intersection of climate change and security is becoming increasingly apparent. New research suggests that climate-induced migration could lead to significant geopolitical shifts in the next decade.',
        authorName: 'Professor Robert Lee',
        authorImage: 'images/placeholder.jpg',
        date: '2025-03-03',
        likes: 28,
        comments: 6,
        hasImage: true,
        imageUrl: 'images/placeholder.jpg'
    },
    {
        id: 'note3',
        content: 'AI ethics in military applications remains an unresolved challenge. Without clear international frameworks, we risk entering a dangerous autonomous weapons race.',
        authorName: 'Dr. Michael Chen',
        authorImage: 'images/placeholder.jpg',
        date: '2025-03-02',
        likes: 19,
        comments: 7,
        hasImage: false
    },
    {
        id: 'note4',
        content: 'Interesting paper on how social media affects political polarization and its implications for international diplomacy. Digital echo chambers don\'t just influence domestic politics—they\'re reshaping how nations interact.',
        authorName: 'Sarah Johnson',
        authorImage: 'images/placeholder.jpg',
        date: '2025-03-01',
        likes: 22,
        comments: 4,
        hasImage: false
    }
];

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize notes functionality
    initNotes();
    
    console.log('Irinfive notes.js initialized');
});

/**
 * Initialize notes functionality
 */
function initNotes() {
    // Check if we're on the notes page
    const notesContainer = document.getElementById('notes-container');
    
    if (notesContainer) {
        // Load notes
        loadNotes();
        
        // Initialize note form
        initNoteForm();
        
        // Initialize load more button
        initLoadMore();
        
        // Initialize note interactions
        setupNoteInteractions();
    }
}

/**
 * Load notes list
 * @param {number} page - Page number for pagination
 * @param {boolean} append - Whether to append or replace notes
 */
function loadNotes(page = 1, append = false) {
    const container = document.getElementById('notes-container');
    
    if (!container) return;
    
    // In production, you would fetch from API with pagination
    // For demo, use the sample data
    const notes = SAMPLE_NOTES;
    
    // Simulate loading state
    if (!append) {
        container.innerHTML = '<div class="loading">Loading notes...</div>';
    }
    
    // Simulate API delay
    setTimeout(() => {
        // Clear loading state if not appending
        if (!append) {
            container.innerHTML = '';
        }
        
        // Append note items
        notes.forEach(note => {
            const noteItem = createNoteItem(note);
            container.appendChild(noteItem);
        });
        
        // Hide "Load More" button when no more notes
        const loadMoreBtn = document.getElementById('load-more-notes');
        if (loadMoreBtn) {
            // In production, you would check if there are more pages
            loadMoreBtn.style.display = page >= 2 ? 'none' : 'block';
        }
        
        // Setup note interactions again for newly added notes
        setupNoteInteractions();
    }, 500);
}

/**
 * Create a note item element
 * @param {Object} note - Note data
 * @returns {HTMLElement} Note item element
 */
function createNoteItem(note) {
    const { id, content, authorName, authorImage, date, likes, comments, hasImage, imageUrl } = note;
    
    // Create note wrapper
    const noteItem = document.createElement('div');
    noteItem.className = 'note-item';
    noteItem.setAttribute('data-id', id);
    
    // Note header
    const header = document.createElement('div');
    header.className = 'note-header';
    header.innerHTML = `
        <div class="note-avatar">
            <img src="${authorImage}" alt="${authorName}">
        </div>
        <div class="note-author">
            <h3>${authorName}</h3>
            <div class="note-date">${window.irinfive?.formatDate(date) || date}</div>
        </div>
        <div class="note-actions">
            <button class="note-actions-btn">⋮</button>
        </div>
    `;
    noteItem.appendChild(header);
    
    // Note content
    const noteContent = document.createElement('div');
    noteContent.className = 'note-content';
    noteContent.innerHTML = `<p>${content}</p>`;
    
    // Add image if present
    if (hasImage && imageUrl) {
        const mediaDiv = document.createElement('div');
        mediaDiv.className = 'note-media';
        mediaDiv.innerHTML = `<img src="${imageUrl}" alt="Note media">`;
        noteContent.appendChild(mediaDiv);
    }
    
    noteItem.appendChild(noteContent);
    
    // Note interactions
    const interactions = document.createElement('div');
    interactions.className = 'note-interactions';
    interactions.innerHTML = `
        <button class="note-interaction-btn like-button" data-id="${id}">
            <span class="note-interaction-icon">❤️</span>
            <span>${likes}</span>
        </button>
        <button class="note-interaction-btn comment-button" data-id="${id}">
            <span class="note-interaction-icon">💬</span>
            <span>${comments}</span>
        </button>
    `;
    noteItem.appendChild(interactions);
    
    return noteItem;
}

/**
 * Initialize note form
 */
function initNoteForm() {
    const form = document.getElementById('note-form');
    
    if (!form) return;
    
    // Show/hide form based on auth status
    const formContainer = document.getElementById('note-form-container');
    if (formContainer) {
        formContainer.style.display = window.irinfive?.isLoggedIn ? 'block' : 'none';
    }
    
    // Handle image upload button
    const imageUploadBtn = document.getElementById('image-upload-btn');
    const imageUploadInput = document.getElementById('image-upload');
    
    if (imageUploadBtn && imageUploadInput) {
        imageUploadBtn.addEventListener('click', function() {
            imageUploadInput.click();
        });
        
        // Show selected image preview
        imageUploadInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                // In production, you would upload to server/storage
                // For demo, just show a preview
                
                // Remove existing preview
                const existingPreview = form.querySelector('.image-preview');
                if (existingPreview) {
                    existingPreview.remove();
                }
                
                // Create preview
                const preview = document.createElement('div');
                preview.className = 'image-preview';
                
                const img = document.createElement('img');
                img.src = URL.createObjectURL(this.files[0]);
                img.alt = 'Upload preview';
                
                const removeBtn = document.createElement('button');
                removeBtn.className = 'remove-image-btn';
                removeBtn.innerHTML = '✕';
                removeBtn.type = 'button';
                removeBtn.addEventListener('click', function() {
                    preview.remove();
                    imageUploadInput.value = '';
                });
                
                preview.appendChild(img);
                preview.appendChild(removeBtn);
                
                // Insert before actions
                const actionsDiv = form.querySelector('.note-form-actions');
                form.insertBefore(preview, actionsDiv);
            }
        });
    }
    
    // Handle form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get content
        const content = document.getElementById('note-content').value.trim();
        
        if (!content) {
            window.irinfive?.showNotification('Please enter some content', 'error');
            return;
        }
        
        // Check if image is selected
        const hasImage = imageUploadInput?.files?.length > 0;
        
        // In production, you would upload to server
        // For demo, create a new note and add to the list
        createNote(content, hasImage);
    });
}

/**
 * Create a new note
 * @param {string} content - Note content
 * @param {boolean} hasImage - Whether note has an image
 */
function createNote(content, hasImage) {
    // Check if user is logged in
    if (!window.irinfive?.isLoggedIn || !window.irinfive?.currentUser) {
        window.irinfive?.showNotification('Please sign in to post notes', 'error');
        return;
    }
    
    // Show loading state
    const submitBtn = document.querySelector('.note-submit-btn');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Posting...';
    }
    
    // Simulate API delay
    setTimeout(() => {
        // Create new note object
        const newNote = {
            id: 'note' + Date.now(),
            content: content,
            authorName: window.irinfive.currentUser.name,
            authorImage: window.irinfive.currentUser.avatar || 'images/placeholder.jpg',
            date: new Date().toISOString(),
            likes: 0,
            comments: 0,
            hasImage: hasImage,
            imageUrl: hasImage ? 'images/placeholder.jpg' : null
        };
        
        // Add to container
        const container = document.getElementById('notes-container');
        if (container) {
            const noteItem = createNoteItem(newNote);
            
            // Add at the beginning
            if (container.firstChild) {
                container.insertBefore(noteItem, container.firstChild);
            } else {
                container.appendChild(noteItem);
            }
            
            // Setup interactions for new note
            setupNoteInteractions();
        }
        
        // Reset form
        document.getElementById('note-content').value = '';
        
        // Remove image preview
        const preview = document.querySelector('.image-preview');
        if (preview) {
            preview.remove();
        }
        
        // Reset file input
        const imageUploadInput = document.getElementById('image-upload');
        if (imageUploadInput) {
            imageUploadInput.value = '';
        }
        
        // Reset button
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Post';
        }
        
        // Show success message
        window.irinfive?.showNotification('Note posted successfully!', 'success');
    }, 1000);
}

/**
 * Initialize load more button
 */
function initLoadMore() {
    const loadMoreBtn = document.getElementById('load-more-notes');
    
    if (!loadMoreBtn) return;
    
    // Track current page
    let currentPage = 1;
    
    loadMoreBtn.addEventListener('click', function() {
        // Increment page
        currentPage++;
        
        // Load more notes
        loadNotes(currentPage, true);
        
        // Update button text
        this.textContent = 'Loading...';
        this.disabled = true;
        
        // Reset button after loading
        setTimeout(() => {
            this.textContent = 'Load More';
            this.disabled = false;
        }, 1000);
    });
}

/**
 * Setup note interaction handlers
 */
function setupNoteInteractions() {
    // Like buttons
    const likeButtons = document.querySelectorAll('.note-item .like-button');
    
    likeButtons.forEach(button => {
        // Remove existing event listeners
        const newButton = button.cloneNode(true);
        button.parentNode.replaceChild(newButton, button);
        
        newButton.addEventListener('click', function() {
            toggleNoteLike(this);
        });
    });
    
    // Comment buttons
    const commentButtons = document.querySelectorAll('.note-item .comment-button');
    
    commentButtons.forEach(button => {
        // Remove existing event listeners
        const newButton = button.cloneNode(true);
        button.parentNode.replaceChild(newButton, button);
        
        newButton.addEventListener('click', function() {
            openCommentsModal(this.getAttribute('data-id'));
        });
    });
    
    // Note actions menu
    const actionsButtons = document.querySelectorAll('.note-actions-btn');
    
    actionsButtons.forEach(button => {
        // Remove existing event listeners
        const newButton = button.cloneNode(true);
        button.parentNode.replaceChild(newButton, button);
        
        newButton.addEventListener('click', function() {
            showNoteActions(this);
        });
    });
}

/**
 * Toggle like on a note
 * @param {HTMLElement} button - Like button element
 */
function toggleNoteLike(button) {
    // Check if user is logged in
    if (!window.irinfive?.isLoggedIn) {
        // Show auth modal
        const authModal = document.getElementById('auth-modal');
        window.irinfive?.openModal(authModal);
        window.irinfive?.showNotification('Please sign in to like notes', 'info');
        return;
    }
    
    // Toggle liked state
    const isLiked = button.classList.contains('liked');
    const countElement = button.querySelector('span:last-child');
    const currentCount = parseInt(countElement.textContent);
    
    if (isLiked) {
        // Unlike
        button.classList.remove('liked');
        countElement.textContent = currentCount - 1;
    } else {
        // Like
        button.classList.add('liked');
        countElement.textContent = currentCount + 1;
    }
    
    // In production, you would call an API
    const noteId = button.getAttribute('data-id');
    console.log(`${isLiked ? 'Unlike' : 'Like'} note: ${noteId}`);
}

/**
 * Show note actions menu
 * @param {HTMLElement} button - Actions button element
 */
function showNoteActions(button) {
    // Get note element
    const noteItem = button.closest('.note-item');
    const noteId = noteItem.getAttribute('data-id');
    
    // Create actions menu
    const actionsMenu = document.createElement('div');
    actionsMenu.className = 'note-actions-menu';
    
    // Add actions based on ownership
    const isOwner = window.irinfive?.isLoggedIn && 
                    window.irinfive?.currentUser?.name === noteItem.querySelector('.note-author h3').textContent;
    
    if (isOwner) {
        // Show edit/delete options
        actionsMenu.innerHTML = `
            <button class="action-btn edit-btn" data-id="${noteId}">Edit</button>
            <button class="action-btn delete-btn" data-id="${noteId}">Delete</button>
        `;
    } else {
        // Show report option
        actionsMenu.innerHTML = `
            <button class="action-btn report-btn" data-id="${noteId}">Report</button>
        `;
    }
    
    // Position menu
    const rect = button.getBoundingClientRect();
    actionsMenu.style.position = 'absolute';
    actionsMenu.style.top = `${rect.bottom + window.scrollY}px`;
    actionsMenu.style.right = `${window.innerWidth - rect.right}px`;
    actionsMenu.style.zIndex = 100;
    
    // Add to document
    document.body.appendChild(actionsMenu);
    
    // Setup action buttons
    const editBtn = actionsMenu.querySelector('.edit-btn');
    if (editBtn) {
        editBtn.addEventListener('click', function() {
            editNote(noteId);
            actionsMenu.remove();
        });
    }
    
    const deleteBtn = actionsMenu.querySelector('.delete-btn');
    if (deleteBtn) {
        deleteBtn.addEventListener('click', function() {
            deleteNote(noteId);
            actionsMenu.remove();
        });
    }
    
    const reportBtn = actionsMenu.querySelector('.report-btn');
    if (reportBtn) {
        reportBtn.addEventListener('click', function() {
            reportNote(noteId);
            actionsMenu.remove();
        });
    }
    
    // Close menu when clicking elsewhere
    document.addEventListener('click', function closeMenu(e) {
        if (!actionsMenu.contains(e.target) && e.target !== button) {
            actionsMenu.remove();
            document.removeEventListener('click', closeMenu);
        }
    });
}

/**
 * Edit a note
 * @param {string} noteId - Note ID
 */
function editNote(noteId) {
    // Get note element
    const noteItem = document.querySelector(`.note-item[data-id="${noteId}"]`);
    
    if (!noteItem) return;
    
    // Get content
    const contentElement = noteItem.querySelector('.note-content p');
    const content = contentElement.textContent;
    
    // Replace content with textarea
    const form = document.createElement('form');
    form.className = 'note-edit-form';
    form.innerHTML = `
        <textarea class="note-edit-textarea">${content}</textarea>
        <div class="note-edit-actions">
            <button type="button" class="note-cancel-btn">Cancel</button>
            <button type="submit" class="note-save-btn">Save</button>
        </div>
    `;
    
    // Replace content element
    const contentContainer = noteItem.querySelector('.note-content');
    const originalContent = contentContainer.innerHTML;
    contentContainer.innerHTML = '';
    contentContainer.appendChild(form);
    
    // Focus textarea
    const textarea = form.querySelector('textarea');
    textarea.focus();
    
    // Setup form actions
    const cancelBtn = form.querySelector('.note-cancel-btn');
    cancelBtn.addEventListener('click', function() {
        // Restore original content
        contentContainer.innerHTML = originalContent;
    });
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get new content
        const newContent = textarea.value.trim();
        
        if (!newContent) {
            window.irinfive?.showNotification('Please enter some content', 'error');
            return;
        }
        
        // In production, you would call an API
        // For demo, just update the content
        contentElement.textContent = newContent;
        
        // Restore normal view
        contentContainer.innerHTML = '';
        contentContainer.appendChild(contentElement);
        
        // Show success message
        window.irinfive?.showNotification('Note updated successfully!', 'success');
    });
}

/**
 * Delete a note
 * @param {string} noteId - Note ID
 */
function deleteNote(noteId) {
    // Confirm deletion
    if (!confirm('Are you sure you want to delete this note?')) {
        return;
    }
    
    // Get note element
    const noteItem = document.querySelector(`.note-item[data-id="${noteId}"]`);
    
    if (!noteItem) return;
    
    // In production, you would call an API
    // For demo, just remove the element
    noteItem.style.opacity = 0;
    
    // Remove after animation
    setTimeout(() => {
        noteItem.remove();
        window.irinfive?.showNotification('Note deleted successfully!', 'success');
    }, 300);
}

/**
 * Report a note
 * @param {string} noteId - Note ID
 */
function reportNote(noteId) {
    // In production, you would open a report form
    // For demo, just show a notification
    window.irinfive?.showNotification('Thank you for your report. We will review this note.', 'success');
}

/**
 * Open comments modal for a note
 * @param {string} noteId - Note ID
 */
function openCommentsModal(noteId) {
    // Get note data
    // In production, you would fetch from API
    const noteData = SAMPLE_NOTES.find(note => note.id === noteId);
    
    if (!noteData) return;
    
    // Get comments modal
    const modal = document.getElementById('comments-modal');
    
    if (!modal) return;
    
    // Set title
    const modalTitle = modal.querySelector('h2');
    if (modalTitle) {
        modalTitle.textContent = 'Comments';
    }
    
    // Load comments
    const commentsList = document.getElementById('comments-list');
    
    if (commentsList) {
        // Clear existing comments
        commentsList.innerHTML = '';
        
        // Show loading state
        commentsList.innerHTML = '<div class="loading">Loading comments...</div>';
        
        // Simulate API delay
        setTimeout(() => {
            // Clear loading state
            commentsList.innerHTML = '';
            
            // In production, you would fetch real comments
            // For demo, show a sample comment
            const comment = document.createElement('div');
            comment.className = 'comment';
            comment.innerHTML = `
                <div class="comment-header">
                    <div class="comment-avatar">
                        <img src="images/placeholder.jpg" alt="Commenter Avatar">
                    </div>
                    <div class="comment-author">
                        <h4>Thomas Wilson</h4>
                        <div class="comment-date">${window.irinfive?.formatDate(new Date().toISOString())}</div>
                    </div>
                </div>
                <div class="comment-content">
                    <p>Fascinating point. I wonder how this will develop in the coming months.</p>
                </div>
            `;
            
            commentsList.appendChild(comment);
            
            // If no comments, show message
            if (commentsList.children.length === 0) {
                commentsList.innerHTML = '<div class="no-comments">No comments yet. Be the first to comment!</div>';
            }
        }, 500);
    }
    
    // Setup comment form
    const commentForm = document.getElementById('comment-form');
    
    if (commentForm) {
        // Clear form
        const textarea = commentForm.querySelector('textarea');
        if (textarea) {
            textarea.value = '';
            
            // Enable/disable based on auth
            textarea.disabled = !window.irinfive?.isLoggedIn;
            textarea.placeholder = window.irinfive?.isLoggedIn ? 'Add a comment...' : 'Please sign in to comment';
        }
        
        // Set note ID
        commentForm.setAttribute('data-note-id', noteId);
        
        // Handle form submission
        commentForm.onsubmit = function(e) {
            e.preventDefault();
            
            // Check if user is logged in
            if (!window.irinfive?.isLoggedIn) {
                window.irinfive?.showNotification('Please sign in to comment', 'error');
                return;
            }
            
            // Get comment content
            const content = textarea.value.trim();
            
            if (!content) {
                window.irinfive?.showNotification('Please enter a comment', 'error');
                return;
            }
            
            // In production, you would call an API
            // For demo, just add the comment to the list
            const comment = document.createElement('div');
            comment.className = 'comment';
            comment.innerHTML = `
                <div class="comment-header">
                    <div class="comment-avatar">
                        <img src="${window.irinfive.currentUser.avatar || 'images/placeholder.jpg'}" alt="${window.irinfive.currentUser.name}">
                    </div>
                    <div class="comment-author">
                        <h4>${window.irinfive.currentUser.name}</h4>
                        <div class="comment-date">${window.irinfive?.formatDate(new Date().toISOString())}</div>
                    </div>
                </div>
                <div class="comment-content">
                    <p>${content}</p>
                </div>
            `;
            
            // Add at the beginning
            if (commentsList.firstChild) {
                commentsList.insertBefore(comment, commentsList.firstChild);
            } else {
                commentsList.appendChild(comment);
            }
            
            // Clear form
            textarea.value = '';
            
            // Remove no comments message if present
            const noComments = commentsList.querySelector('.no-comments');
            if (noComments) {
                noComments.remove();
            }
            
            // Show success message
            window.irinfive?.showNotification('Comment added successfully!', 'success');
            
            // Update comment count on note
            const noteCommentBtn = document.querySelector(`.note-item[data-id="${noteId}"] .comment-button span:last-child`);
            if (noteCommentBtn) {
                const count = parseInt(noteCommentBtn.textContent) + 1;
                noteCommentBtn.textContent = count;
            }
        };
    }
    
    // Open modal
    window.irinfive?.openModal(modal);
}