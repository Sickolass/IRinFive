/**
 * Pagination functionality for article listings
 * Handles pagination without page refresh or jumping to top
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize pagination if it exists on the page
    initPagination();
    
    // Initialize filter navigation
    initFilterNav();
    
    // Add a loading indicator style
    addLoadingStyles();
  });
  
  /**
   * Initialize pagination functionality
   */
  function initPagination() {
    const paginationContainer = document.querySelector('.pagination');
    
    if (!paginationContainer) return;
    
    // Get all page links
    const pageLinks = paginationContainer.querySelectorAll('.page-link');
    
    // Add click event to each link
    pageLinks.forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault(); // Prevent default anchor behavior
        
        // Remove active class from all links
        pageLinks.forEach(pageLink => pageLink.classList.remove('active'));
        
        // Add active class to clicked link
        this.classList.add('active');
        
        // Get the page number or action (next/prev)
        const pageAction = this.textContent.trim();
        
        // Load the appropriate page content
        loadPageContent(pageAction);
      });
    });
  }
  
  /**
   * Initialize filter navigation
   */
  function initFilterNav() {
    const filterContainer = document.querySelector('.filter-nav');
    
    if (!filterContainer) return;
    
    // Get all filter options
    const filterOptions = filterContainer.querySelectorAll('.filter-option');
    
    // Add click event to each option
    filterOptions.forEach(option => {
      option.addEventListener('click', function(e) {
        e.preventDefault(); // Prevent default anchor behavior
        
        // Remove active class from all options
        filterOptions.forEach(opt => opt.classList.remove('active'));
        
        // Add active class to clicked option
        this.classList.add('active');
        
        // Get the filter type
        const filterType = this.getAttribute('data-filter');
        
        // Apply the filter
        applyFilter(filterType);
      });
    });
  }
  
  /**
   * Load page content based on page number or action
   * @param {string} pageAction - Page number or 'Next'/'Prev' action
   */
  function loadPageContent(pageAction) {
    // Get the current articles container
    const articlesContainer = document.getElementById('articles-container');
    
    // Save the current scroll position
    const articlesSection = document.getElementById('articles');
    const articlesSectionTop = articlesSection.getBoundingClientRect().top + window.scrollY;
    
    // Scroll to the top of the articles section (slightly higher)
    window.scrollTo({
      top: articlesSectionTop - 100, // Position 100px above the articles section
      behavior: 'smooth'
    });
    
    // For demonstration, we'll simulate loading different content
    // In a real implementation, this would fetch content from a server
    
    // Determine the page number
    let pageNumber;
    
    if (pageAction === 'Next →') {
      // Get the currently active page and go to the next one
      const activePage = document.querySelector('.pagination .active');
      pageNumber = parseInt(activePage.textContent) + 1;
    } else {
      // Use the clicked page number
      pageNumber = parseInt(pageAction);
    }
    
    // Simulate loading with a brief delay
    articlesContainer.innerHTML = '<div class="loading">Loading page ' + pageNumber + '...</div>';
    
    // In a real application, you would fetch the appropriate content from the server
    // For now, we'll just simulate with a timeout
    setTimeout(() => {
      // Simulate new content (in a real app, this would be from an API)
      let newContent = '';
      
      // Generate different articles based on page number
      for (let i = 1; i <= 3; i++) {
        const articleIndex = (pageNumber - 1) * 3 + i;
        newContent += `
          <div class="article-card">
            <div class="article-image">
              <a href="post.html?slug=sample-article-${articleIndex}">
                <img src="images/placeholder.jpg" alt="Sample Article ${articleIndex}">
              </a>
            </div>
            <div class="article-content">
              <div class="article-meta">
                <span class="article-date">Mar ${articleIndex}, 2025</span>
                <span class="article-readtime">${Math.floor(Math.random() * 10) + 3} min read</span>
              </div>
              <h2 class="article-title">
                <a href="post.html?slug=sample-article-${articleIndex}">Sample Article ${articleIndex} for Page ${pageNumber}</a>
              </h2>
              <p class="article-excerpt">
                This is a sample article excerpt for page ${pageNumber}. The content would be different for each article.
              </p>
              <a href="post.html?slug=sample-article-${articleIndex}" class="read-more">Read More</a>
              <div class="article-interactions">
                <button class="like-button" data-slug="sample-article-${articleIndex}">
                  <span class="like-icon">❤️</span>
                  <span class="like-count">${Math.floor(Math.random() * 50)}</span>
                </button>
                <button class="comment-button" data-slug="sample-article-${articleIndex}">
                  <span class="comment-icon">💬</span>
                  <span class="comment-count">${Math.floor(Math.random() * 20)}</span>
                </button>
              </div>
            </div>
          </div>
        `;
      }
      
      // Update the articles container
      articlesContainer.innerHTML = newContent;
      
      // Apply animations to the new content
      const newArticles = articlesContainer.querySelectorAll('.article-card');
      newArticles.forEach((article, index) => {
        // Set initial styles
        article.style.opacity = '0';
        article.style.transform = 'translateY(20px)';
        article.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        
        // Animate with slight delay for each article
        setTimeout(() => {
          article.style.opacity = '1';
          article.style.transform = 'translateY(0)';
        }, index * 100);
      });
      
      // Update the active page in pagination
      updatePaginationUI(pageNumber);
    }, 500);
  }
  
  /**
   * Add custom loading indicator styles to the document
   */
  function addLoadingStyles() {
    // Create a style element
    const style = document.createElement('style');
    
    // Add the CSS for the loading indicator
    style.textContent = `
      .loading {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 2rem;
        color: var(--text-secondary);
        font-size: 1.2rem;
        height: 200px;
        grid-column: 1 / -1;
        position: relative;
      }
  
      .loading:after {
        content: '';
        width: 30px;
        height: 30px;
        border: 3px solid var(--accent-color);
        border-radius: 50%;
        border-top-color: transparent;
        animation: loader-spin 1s linear infinite;
        position: absolute;
        top: calc(50% + 30px);
        left: 50%;
        transform: translate(-50%, -50%);
      }
  
      @keyframes loader-spin {
        0% { transform: translate(-50%, -50%) rotate(0deg); }
        100% { transform: translate(-50%, -50%) rotate(360deg); }
      }
    `;
    
    // Add the style element to the document head
    document.head.appendChild(style);
  }
  
  /**
   * Update pagination UI to reflect the current page
   * @param {number} currentPage - Current page number
   */
  function updatePaginationUI(currentPage) {
    const paginationContainer = document.querySelector('.pagination');
    const pageLinks = paginationContainer.querySelectorAll('.page-link');
    
    // Remove active class from all links
    pageLinks.forEach(link => link.classList.remove('active'));
    
    // Find and activate the current page link
    pageLinks.forEach(link => {
      const linkText = link.textContent.trim();
      if (linkText === currentPage.toString()) {
        link.classList.add('active');
      }
    });
    
    // Update Next button status
    const nextButton = paginationContainer.querySelector('.next');
    if (currentPage >= 3) { // Assuming 3 is the max page
      nextButton.style.opacity = '0.5';
      nextButton.style.pointerEvents = 'none';
    } else {
      nextButton.style.opacity = '1';
      nextButton.style.pointerEvents = 'auto';
    }
  }
  
  /**
   * Apply filter to articles
   * @param {string} filterType - Type of filter (latest, top, discussions)
   */
  function applyFilter(filterType) {
    // Get the articles container
    const articlesContainer = document.getElementById('articles-container');
    
    // Save the current scroll position
    const articlesSection = document.getElementById('articles');
    const articlesSectionTop = articlesSection.getBoundingClientRect().top + window.scrollY;
    
    // Scroll to the top of the articles section (slightly higher)
    window.scrollTo({
      top: articlesSectionTop - 100, // Position 100px above the articles section
      behavior: 'smooth'
    });
    
    // Show loading state
    articlesContainer.innerHTML = '<div class="loading">Loading ' + filterType + ' articles...</div>';
    
    // In a real application, you would fetch filtered content from the server
    // For now, we'll just simulate with a timeout
    setTimeout(() => {
      // Simulate different content based on filter type
      let newContent = '';
      
      // Generate different articles based on filter type
      for (let i = 1; i <= 3; i++) {
        let title, excerpt, likes, comments, date;
        
        switch (filterType) {
          case 'latest':
            title = `Latest Article ${i}`;
            excerpt = `This is a recent article that was just published. It covers the latest developments in international relations.`;
            likes = Math.floor(Math.random() * 20);
            comments = Math.floor(Math.random() * 10);
            date = `Mar ${i}, 2025`;
            break;
          case 'top':
            title = `Top Rated Article ${i}`;
            excerpt = `This article has received significant attention and many positive reactions from readers.`;
            likes = Math.floor(Math.random() * 50) + 30;
            comments = Math.floor(Math.random() * 20) + 10;
            date = `Feb ${20 + i}, 2025`;
            break;
          case 'discussions':
            title = `Most Discussed Article ${i}`;
            excerpt = `This article has sparked significant discussion in the community with many different perspectives.`;
            likes = Math.floor(Math.random() * 30) + 10;
            comments = Math.floor(Math.random() * 30) + 20;
            date = `Feb ${15 + i}, 2025`;
            break;
        }
        
        newContent += `
          <div class="article-card">
            <div class="article-image">
              <a href="post.html?slug=${filterType}-article-${i}">
                <img src="images/placeholder.jpg" alt="${title}">
              </a>
            </div>
            <div class="article-content">
              <div class="article-meta">
                <span class="article-date">${date}</span>
                <span class="article-readtime">${Math.floor(Math.random() * 10) + 3} min read</span>
              </div>
              <h2 class="article-title">
                <a href="post.html?slug=${filterType}-article-${i}">${title}</a>
              </h2>
              <p class="article-excerpt">
                ${excerpt}
              </p>
              <a href="post.html?slug=${filterType}-article-${i}" class="read-more">Read More</a>
              <div class="article-interactions">
                <button class="like-button" data-slug="${filterType}-article-${i}">
                  <span class="like-icon">❤️</span>
                  <span class="like-count">${likes}</span>
                </button>
                <button class="comment-button" data-slug="${filterType}-article-${i}">
                  <span class="comment-icon">💬</span>
                  <span class="comment-count">${comments}</span>
                </button>
              </div>
            </div>
          </div>
        `;
      }
      
      // Update the articles container
      articlesContainer.innerHTML = newContent;
      
      // Apply animations to the new content
      const newArticles = articlesContainer.querySelectorAll('.article-card');
      newArticles.forEach((article, index) => {
        // Set initial styles
        article.style.opacity = '0';
        article.style.transform = 'translateY(20px)';
        article.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        
        // Animate with slight delay for each article
        setTimeout(() => {
          article.style.opacity = '1';
          article.style.transform = 'translateY(0)';
        }, index * 100);
      });
      
      // Reset pagination to page 1
      const pageLinks = document.querySelectorAll('.pagination .page-link');
      pageLinks.forEach(link => link.classList.remove('active'));
      pageLinks[0].classList.add('active');
    }, 500);
  }