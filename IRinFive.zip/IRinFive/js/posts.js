/**
 * Irinfive - Posts JavaScript
 * Handles post-related functionality (listing, viewing, interactions)
 */

// Sample post data (this will come from your API in production)
const SAMPLE_POSTS = [
    {
        slug: 'the-future-of-ai',
        title: 'The Future of AI and International Relations',
        subtitle: 'How artificial intelligence is reshaping the landscape of global politics and security in the modern era.',
        date: '2025-03-04',
        excerpt: 'How artificial intelligence is reshaping the landscape of global politics and security in the modern era.',
        readingTime: 5,
        coverImage: 'images/article2.jpg',
        topics: ['Technology', 'Security', 'International Relations'],
        likes: 24,
        comments: 8,
        authorName: 'Dr. Jane Smith',
        authorImage: 'images/article2.jpg',
        featured: true
    },
    {
        slug: 'cybersecurity-challenges',
        title: 'Cybersecurity Challenges in a Connected World',
        subtitle: 'Examining the growing threats to national security in cyberspace and strategies for resilience.',
        date: '2025-02-28',
        excerpt: 'Examining the growing threats to national security in cyberspace and strategies for resilience.',
        readingTime: 7,
        coverImage: 'images/article2.jpg',
        topics: ['Security', 'Technology', 'Cybersecurity'],
        likes: 18,
        comments: 5,
        authorName: 'Professor Robert Lee',
        authorImage: 'images/placeholder.jpg',
        featured: false
    },
    {
        slug: 'climate-security',
        title: 'Climate Change as a Security Threat',
        subtitle: 'Understanding how climate change impacts global security, resource conflicts, and migration patterns.',
        date: '2025-02-20',
        excerpt: 'Understanding how climate change impacts global security, resource conflicts, and migration patterns.',
        readingTime: 6,
        coverImage: 'images/article2.jpg',
        topics: ['Climate', 'Security', 'Migration'],
        likes: 32,
        comments: 12,
        authorName: 'Dr. Michael Chen',
        authorImage: 'images/article2.jpg',
        featured: false
    },
    {
        slug: 'nuclear-proliferation',
        title: 'Nuclear Proliferation in the 21st Century',
        subtitle: 'Analyzing the current state of nuclear proliferation and the effectiveness of international treaties.',
        date: '2025-02-12',
        excerpt: 'Analyzing the current state of nuclear proliferation and the effectiveness of international treaties.',
        readingTime: 8,
        coverImage: 'images/article2.jpg',
        topics: ['Security', 'Nuclear', 'International Relations'],
        likes: 15,
        comments: 7,
        authorName: 'Dr. Jane Smith',
        authorImage: 'images/placeholder.jpg',
        featured: false
    },
    {
        slug: 'diplomatic-strategies',
        title: 'Diplomatic Strategies for a Polarized World',
        subtitle: 'How diplomacy is evolving to address global challenges in an increasingly fractured international system.',
        date: '2025-02-05',
        excerpt: 'How diplomacy is evolving to address global challenges in an increasingly fractured international system.',
        readingTime: 9,
        coverImage: 'images/article2.jpg',
        topics: ['Politics', 'Diplomacy', 'International Relations'],
        likes: 20,
        comments: 9,
        authorName: 'Professor Robert Lee',
        authorImage: 'images/placeholder.jpg',
        featured: false
    },
    {
        slug: 'quantum-computing',
        title: 'Quantum Computing and National Security',
        subtitle: 'Exploring the implications of quantum computing for encryption, cybersecurity, and intelligence gathering.',
        date: '2025-01-28',
        excerpt: 'Exploring the implications of quantum computing for encryption, cybersecurity, and intelligence gathering.',
        readingTime: 7,
        coverImage: 'images/article2.jpg',
        topics: ['Technology', 'Security', 'Quantum'],
        likes: 27,
        comments: 6,
        authorName: 'Dr. Michael Chen',
        authorImage: 'images/placeholder.jpg',
        featured: false
    }
];

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize post-related functionality
    initPosts();
    
    console.log('Irinfive posts.js initialized');
});

/**
 * Initialize post-related functionality
 */
function initPosts() {
    // Check if we're on the post detail page
    const postSlug = window.irinfive?.getUrlParams()?.slug;
    
    if (postSlug) {
        // Post detail page
        loadPostDetail(postSlug);
        setupPostInteractions();
    } else {
        // List pages (home, archive)
        if (document.getElementById('articles-container')) {
            loadPostList();
        }
        
        if (document.getElementById('archive-container')) {
            loadArchiveList();
        }
    }
    
    // Initialize post filter functionality
    initPostFilters();
}

/**
 * Load post list based on current page and filters
 * @param {string} filter - Filter type (latest, top, discussions)
 */
function loadPostList(filter = 'latest') {
    const container = document.getElementById('articles-container');
    
    if (!container) return;
    
    // In production, you would fetch from API
    // For demo, filter the sample data
    let posts = [...SAMPLE_POSTS];
    
    // Apply filter
    switch (filter) {
        case 'top':
            posts.sort((a, b) => b.likes - a.likes);
            break;
        case 'discussions':
            posts.sort((a, b) => b.comments - a.comments);
            break;
        case 'latest':
        default:
            posts.sort((a, b) => new Date(b.date) - new Date(a.date));
            break;
    }
    
    // Clear container
    container.innerHTML = '';
    
    // Append post cards
    posts.forEach(post => {
        const postCard = createPostCard(post);
        container.appendChild(postCard);
    });
    
    // Setup interactions after posts are loaded
    setupPostInteractions();
}

/**
 * Create a post card element
 * @param {Object} post - Post data
 * @returns {HTMLElement} Post card element
 */
function createPostCard(post) {
    const { slug, title, excerpt, date, readingTime, coverImage, likes, comments } = post;
    
    // Create card wrapper
    const card = document.createElement('div');
    card.className = 'article-card';
    
    // Card inner HTML
    card.innerHTML = `
        <div class="article-image">
            <a href="post.html?slug=${slug}">
                <img src="${coverImage}" alt="${title}">
            </a>
        </div>
        <div class="article-content">
            <div class="article-meta">
                <span class="article-date">${window.irinfive?.formatDate(date) || date}</span>
                <span class="article-readtime">${readingTime} min read</span>
            </div>
            <h2 class="article-title">
                <a href="post.html?slug=${slug}">${title}</a>
            </h2>
            <p class="article-excerpt">${excerpt}</p>
            <a href="post.html?slug=${slug}" class="read-more">Read More</a>
            <div class="article-interactions">
                <button class="like-button" data-slug="${slug}">
                    <span class="like-icon">❤️</span>
                    <span class="like-count">${likes}</span>
                </button>
                <button class="comment-button" data-slug="${slug}">
                    <span class="comment-icon">💬</span>
                    <span class="comment-count">${comments}</span>
                </button>
            </div>
        </div>
    `;
    
    return card;
}

/**
 * Load archive list with filtering
 * @param {Object} filters - Filter options (year, topic, search)
 */
function loadArchiveList(filters = {}) {
    const container = document.getElementById('archive-container');
    
    if (!container) return;
    
    // In production, you would fetch from API
    let posts = [...SAMPLE_POSTS];
    
    // Apply filters
    if (filters.year && filters.year !== 'all') {
        const year = filters.year;
        posts = posts.filter(post => {
            const postYear = new Date(post.date).getFullYear().toString();
            return postYear === year;
        });
    }
    
    if (filters.topic && filters.topic !== 'all') {
        const topic = filters.topic.toLowerCase();
        posts = posts.filter(post => {
            return post.topics.some(t => t.toLowerCase() === topic);
        });
    }
    
    if (filters.search && filters.search.trim()) {
        const search = filters.search.toLowerCase().trim();
        posts = posts.filter(post => {
            return (
                post.title.toLowerCase().includes(search) ||
                post.excerpt.toLowerCase().includes(search) ||
                post.topics.some(t => t.toLowerCase().includes(search))
            );
        });
    }
    
    // Clear container
    container.innerHTML = '';
    
    if (posts.length === 0) {
        // Show no results message
        container.innerHTML = `
            <div class="no-results">
                <p>No articles found matching your search criteria.</p>
            </div>
        `;
        return;
    }
    
    // Sort by date (newest first)
    posts.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // Append archive items
    posts.forEach(post => {
        const archiveItem = createArchiveItem(post);
        container.appendChild(archiveItem);
    });
}

/**
 * Create an archive item element
 * @param {Object} post - Post data
 * @returns {HTMLElement} Archive item element
 */
function createArchiveItem(post) {
    const { slug, title, excerpt, date, readingTime, topics } = post;
    
    // Create archive item wrapper as a link
    const item = document.createElement('a');
    item.className = 'archive-item';
    item.href = `post.html?slug=${slug}`;
    
    // Get primary topic
    const primaryTopic = topics && topics.length > 0 ? topics[0] : 'General';
    
    // Item inner HTML
    item.innerHTML = `
        <div class="archive-item-details">
            <div class="archive-date">${window.irinfive?.formatDate(date) || date}</div>
            <h2 class="archive-title">${title}</h2>
            <p class="archive-excerpt">${excerpt}</p>
        </div>
        <div class="archive-meta">
            <span class="archive-topic">${primaryTopic}</span>
            <span class="archive-readtime">${readingTime} min read</span>
        </div>
    `;
    
    return item;
}

/**
 * Load post detail by slug
 * @param {string} slug - Post slug
 */
function loadPostDetail(slug) {
    // In production, you would fetch from API
    const post = SAMPLE_POSTS.find(p => p.slug === slug);
    
    if (!post) {
        // Post not found
        window.irinfive?.showNotification('Post not found', 'error');
        return;
    }
    
    // Set page title
    document.title = `${post.title} - Irinfive`;
    
    // Update post content
    updatePostMeta(post);
    
    // Track view (in production, call an API)
    trackPostView(slug);
    
    // Load related posts
    loadRelatedPosts(post);
}

/**
 * Update post metadata and content
 * @param {Object} post - Post data
 */
function updatePostMeta(post) {
    // Update title
    const titleEl = document.querySelector('.post-title');
    if (titleEl) titleEl.textContent = post.title;
    
    // Update meta
    const dateEl = document.querySelector('.post-date');
    if (dateEl) dateEl.textContent = window.irinfive?.formatDate(post.date) || post.date;
    
    const readtimeEl = document.querySelector('.post-readtime');
    if (readtimeEl) readtimeEl.textContent = `${post.readingTime} min read`;
    
    const topicEl = document.querySelector('.post-topic');
    if (topicEl && post.topics && post.topics.length > 0) {
        topicEl.textContent = post.topics[0];
    }
    
    // Update cover image
    const coverEl = document.querySelector('.post-cover img');
    if (coverEl) {
        coverEl.src = post.coverImage;
        coverEl.alt = post.title;
    }
    
    // Update like count
    const likeCount = document.querySelector('.post-like-btn .like-count');
    if (likeCount) likeCount.textContent = post.likes;
    
    // Update author info
    const authorName = document.querySelector('.author-bio h3');
    if (authorName) authorName.textContent = post.authorName;
    
    const authorAvatar = document.querySelector('.author-avatar img');
    if (authorAvatar) authorAvatar.src = post.authorImage;
    
    // Update tags
    const tagsContainer = document.querySelector('.post-tags');
    if (tagsContainer && post.topics) {
        tagsContainer.innerHTML = '';
        post.topics.forEach(topic => {
            const tag = document.createElement('span');
            tag.className = 'post-tag';
            tag.textContent = topic;
            tagsContainer.appendChild(tag);
        });
    }
    
    // Update comments count
    const commentsCount = document.querySelector('#comments-count');
    if (commentsCount) commentsCount.textContent = `${post.comments} Comments`;
}

/**
 * Track post view
 * @param {string} slug - Post slug
 */
function trackPostView(slug) {
    // In production, you would call an API
    console.log(`Tracking view for post: ${slug}`);
    
    // Simulate API call
    setTimeout(() => {
        // Update UI if needed
    }, 500);
}

/**
 * Load related posts
 * @param {Object} currentPost - Current post data
 */
function loadRelatedPosts(currentPost) {
    const container = document.querySelector('.related-posts .articles-grid');
    
    if (!container) return;
    
    // In production, you would fetch from API
    // For demo, find posts with similar topics
    const relatedPosts = SAMPLE_POSTS
        .filter(post => post.slug !== currentPost.slug) // Exclude current post
        .filter(post => {
            // Find posts with at least one matching topic
            return post.topics.some(topic => 
                currentPost.topics.includes(topic)
            );
        })
        .sort((a, b) => {
            // Sort by number of matching topics (descending)
            const aMatchCount = a.topics.filter(topic => 
                currentPost.topics.includes(topic)
            ).length;
            
            const bMatchCount = b.topics.filter(topic => 
                currentPost.topics.includes(topic)
            ).length;
            
            return bMatchCount - aMatchCount;
        })
        .slice(0, 2); // Get top 2 related posts
    
    // Clear container
    container.innerHTML = '';
    
    // Append related post cards
    relatedPosts.forEach(post => {
        const postCard = createPostCard(post);
        container.appendChild(postCard);
    });
}

/**
 * Initialize post filter functionality
 */
function initPostFilters() {
    // Home page filters
    const filterOptions = document.querySelectorAll('.filter-nav .filter-option');
    
    filterOptions.forEach(option => {
        option.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Update active class
            filterOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
            
            // Load posts with filter
            const filter = this.getAttribute('data-filter');
            loadPostList(filter);
        });
    });
    
    // Archive page filters
    const yearFilter = document.getElementById('year-filter');
    const topicFilter = document.getElementById('topic-filter');
    const archiveSearch = document.getElementById('archive-search');
    const searchButton = document.getElementById('search-button');
    
    // Apply filters when changed
    const applyArchiveFilters = () => {
        const filters = {
            year: yearFilter?.value || 'all',
            topic: topicFilter?.value || 'all',
            search: archiveSearch?.value || ''
        };
        
        loadArchiveList(filters);
    };
    
    // Set up event listeners
    if (yearFilter) {
        yearFilter.addEventListener('change', applyArchiveFilters);
    }
    
    if (topicFilter) {
        topicFilter.addEventListener('change', applyArchiveFilters);
    }
    
    if (searchButton && archiveSearch) {
        searchButton.addEventListener('click', function(e) {
            e.preventDefault();
            applyArchiveFilters();
        });
        
        // Also allow search on Enter key
        archiveSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                applyArchiveFilters();
            }
        });
    }
}

/**
 * Setup post interaction handlers (like, comment buttons)
 */
function setupPostInteractions() {
    // Like buttons
    const likeButtons = document.querySelectorAll('.like-button, .post-like-btn');
    
    likeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const slug = this.getAttribute('data-slug');
            toggleLike(this, slug);
        });
    });
    
    // Comment buttons on post cards
    const commentButtons = document.querySelectorAll('.comment-button');
    
    commentButtons.forEach(button => {
        button.addEventListener('click', function() {
            const slug = this.getAttribute('data-slug');
            window.location.href = `post.html?slug=${slug}#comments`;
        });
    });
    
    // Share buttons
    const shareButtons = document.querySelectorAll('.share-btn');
    
    shareButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const platform = this.classList.contains('twitter') ? 'twitter' :
                            this.classList.contains('facebook') ? 'facebook' :
                            this.classList.contains('linkedin') ? 'linkedin' : 'social';
            
            sharePost(platform);
        });
    });
}

/**
 * Toggle like on a post
 * @param {HTMLElement} button - Like button element
 * @param {string} slug - Post slug
 */
function toggleLike(button, slug) {
    // Check if user is logged in
    if (!window.irinfive?.isLoggedIn) {
        // Show auth modal
        const authModal = document.getElementById('auth-modal');
        window.irinfive?.openModal(authModal);
        window.irinfive?.showNotification('Please sign in to like posts', 'info');
        return;
    }
    
    // Toggle liked state
    const isLiked = button.classList.contains('liked');
    const countElement = button.querySelector('.like-count');
    const currentCount = parseInt(countElement.textContent);
    
    if (isLiked) {
        // Unlike
        button.classList.remove('liked');
        countElement.textContent = currentCount - 1;
    } else {
        // Like
        button.classList.add('liked');
        countElement.textContent = currentCount + 1;
    }
    
    // In production, you would call an API
    console.log(`${isLiked ? 'Unlike' : 'Like'} post: ${slug}`);
    
    // Show feedback
    window.irinfive?.showNotification(
        isLiked ? 'Removed from your likes' : 'Added to your likes',
        'success'
    );
}

/**
 * Share post on social media
 * @param {string} platform - Social media platform
 */
function sharePost(platform) {
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);
    
    let shareUrl;
    
    switch (platform) {
        case 'twitter':
            shareUrl = `https://twitter.com/intent/tweet?url=${url}&text=${title}`;
            break;
        case 'facebook':
            shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
            break;
        case 'linkedin':
            shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
            break;
        default:
            // Fallback to navigator.share if available
            if (navigator.share) {
                navigator.share({
                    title: document.title,
                    url: window.location.href
                }).then(() => {
                    console.log('Thanks for sharing!');
                }).catch(console.error);
                return;
            }
            
            shareUrl = `mailto:?subject=${title}&body=${url}`;
            break;
    }
    
    // Open in new window
    window.open(shareUrl, '_blank', 'width=600,height=400');
}