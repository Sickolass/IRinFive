/**
 * Irinfive - Main JavaScript
 * Handles core functionality, authentication, and shared components
 */

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
  // Initialize components
  initModals();
  initAuth();
  setupMobileMenu();
  
  // Apply fade-in animations to elements
  applyAnimations();
  
  // Check if user is logged in from localStorage
  checkAuthStatus();
  
  console.log('Irinfive main.js initialized');
});

// Authentication state
let isLoggedIn = false;
let currentUser = null;

/**
* Initialize modal dialogs
*/
function initModals() {
  // Get all modals
  const modals = document.querySelectorAll('.modal');
  const modalTriggers = document.querySelectorAll('[id$="-btn"]');
  const closeButtons = document.querySelectorAll('.close-modal');
  
  // Open modal when trigger is clicked
  modalTriggers.forEach(trigger => {
      const modalId = trigger.id.replace('-btn', '-modal');
      const modal = document.getElementById(modalId);
      
      if (modal) {
          trigger.addEventListener('click', function() {
              openModal(modal);
          });
      }
  });
  
  // Close modal when close button is clicked
  closeButtons.forEach(button => {
      button.addEventListener('click', function() {
          const modal = button.closest('.modal');
          closeModal(modal);
      });
  });
  
  // Close modal when clicking outside the content
  modals.forEach(modal => {
      modal.addEventListener('click', function(event) {
          if (event.target === modal) {
              closeModal(modal);
          }
      });
  });
  
  // Close modal with Escape key
  document.addEventListener('keydown', function(event) {
      if (event.key === 'Escape') {
          modals.forEach(modal => {
              if (modal.style.display === 'block') {
                  closeModal(modal);
              }
          });
      }
  });
}

/**
* Open a modal dialog
* @param {HTMLElement} modal - The modal element to open
*/
function openModal(modal) {
  if (modal) {
      modal.style.display = 'block';
      document.body.style.overflow = 'hidden'; // Prevent scrolling
  }
}

/**
* Close a modal dialog
* @param {HTMLElement} modal - The modal element to close
*/
function closeModal(modal) {
  if (modal) {
      modal.style.display = 'none';
      document.body.style.overflow = ''; // Restore scrolling
  }
}

/**
* Initialize authentication functionality
*/
function initAuth() {
  const authModal = document.getElementById('auth-modal');
  const signinForm = document.getElementById('signin-form');
  const signupToggle = document.getElementById('signup-toggle');
  const authBtn = document.getElementById('auth-btn');
  
  // Toggle between sign in and sign up
  if (signupToggle) {
      signupToggle.addEventListener('click', function(e) {
          e.preventDefault();
          
          const authContainer = document.querySelector('.auth-container');
          const heading = authContainer.querySelector('h2');
          const submitBtn = authContainer.querySelector('.auth-submit');
          const toggleText = authContainer.querySelector('.auth-toggle');
          
          if (heading.textContent === 'Sign In') {
              // Switch to sign up form
              heading.textContent = 'Sign Up';
              submitBtn.textContent = 'Sign Up';
              toggleText.innerHTML = 'Already have an account? <a href="#" id="signin-toggle">Sign In</a>';
              
              // Add name field
              if (!document.getElementById('signup-name')) {
                  const emailField = document.getElementById('signin-email').parentNode;
                  const nameField = document.createElement('div');
                  nameField.className = 'form-group';
                  nameField.innerHTML = `
                      <label for="signup-name">Name</label>
                      <input type="text" id="signup-name" name="name" required>
                  `;
                  emailField.parentNode.insertBefore(nameField, emailField);
              }
              
              // Add signin toggle event
              const signinToggle = document.getElementById('signin-toggle');
              signinToggle.addEventListener('click', function(e) {
                  e.preventDefault();
                  
                  // Switch back to sign in form
                  heading.textContent = 'Sign In';
                  submitBtn.textContent = 'Sign In';
                  toggleText.innerHTML = 'Don\'t have an account? <a href="#" id="signup-toggle">Sign Up</a>';
                  
                  // Remove name field
                  const nameField = document.getElementById('signup-name').parentNode;
                  nameField.remove();
                  
                  // Re-add sign up toggle event
                  document.getElementById('signup-toggle').addEventListener('click', arguments.callee);
              });
          }
      });
  }
  
  // Handle sign in form submission
  if (signinForm) {
      signinForm.addEventListener('submit', function(e) {
          e.preventDefault();
          
          const email = document.getElementById('signin-email').value;
          const password = document.getElementById('signin-password').value;
          
          // In a real implementation, you would validate and send to a server
          // For demo, just simulate login
          simulateLogin(email);
      });
  }
  
  // Handle log out
  if (authBtn && authBtn.classList.contains('logged-in')) {
      authBtn.addEventListener('click', function(e) {
          if (isLoggedIn) {
              e.preventDefault();
              e.stopPropagation();
              
              // Show logout option
              const logoutMenu = document.createElement('div');
              logoutMenu.className = 'logout-menu';
              logoutMenu.innerHTML = '<button id="logout-btn">Log Out</button>';
              
              document.body.appendChild(logoutMenu);
              
              // Position the menu below the auth button
              const rect = authBtn.getBoundingClientRect();
              logoutMenu.style.top = rect.bottom + 'px';
              logoutMenu.style.left = rect.left + 'px';
              
              // Handle logout button click
              document.getElementById('logout-btn').addEventListener('click', function() {
                  logout();
                  logoutMenu.remove();
              });
              
              // Close menu when clicking elsewhere
              document.addEventListener('click', function closeLogout(e) {
                  if (!logoutMenu.contains(e.target) && e.target !== authBtn) {
                      logoutMenu.remove();
                      document.removeEventListener('click', closeLogout);
                  }
              });
          }
      });
  }
}

/**
* Simulate a login for demo purposes
* @param {string} email - User's email
*/
function simulateLogin(email) {
  // Simulate server response
  setTimeout(() => {
      // Create a simulated user object
      const user = {
          id: 'user123',
          email: email,
          name: email.split('@')[0],
          avatar: 'images/placeholder.jpg'
      };
      
      // Set authentication state
      isLoggedIn = true;
      currentUser = user;
      
      // Store in localStorage for persistence
      localStorage.setItem('irinfive_user', JSON.stringify(user));
      
      // Update UI
      updateAuthUI();
      
      // Close modal
      closeModal(document.getElementById('auth-modal'));
      
      // Show success message
      showNotification('You have been logged in successfully!', 'success');
  }, 1000);
}

/**
* Log out the current user
*/
function logout() {
  // Clear authentication state
  isLoggedIn = false;
  currentUser = null;
  
  // Remove from localStorage
  localStorage.removeItem('irinfive_user');
  
  // Update UI
  updateAuthUI();
  
  // Show success message
  showNotification('You have been logged out successfully!', 'success');
}

/**
* Check if user is already logged in from localStorage
*/
function checkAuthStatus() {
  const storedUser = localStorage.getItem('irinfive_user');
  
  if (storedUser) {
      try {
          currentUser = JSON.parse(storedUser);
          isLoggedIn = true;
          updateAuthUI();
      } catch (e) {
          console.error('Failed to parse stored user:', e);
          localStorage.removeItem('irinfive_user');
      }
  }
}

/**
* Update UI based on authentication state
*/
function updateAuthUI() {
  const authBtn = document.getElementById('auth-btn');
  
  if (authBtn) {
      if (isLoggedIn && currentUser) {
          // Update button to show user is logged in
          authBtn.textContent = currentUser.name;
          authBtn.classList.add('logged-in');
          
          // Show user avatar if possible
          if (currentUser.avatar) {
              const avatar = document.createElement('img');
              avatar.src = currentUser.avatar;
              avatar.className = 'auth-avatar';
              avatar.alt = currentUser.name;
              
              // Replace text with avatar
              authBtn.innerHTML = '';
              authBtn.appendChild(avatar);
              
              // Add user name
              const userName = document.createElement('span');
              userName.textContent = currentUser.name;
              authBtn.appendChild(userName);
          }
          
          // Show note form if it exists
          const noteForm = document.getElementById('note-form-container');
          if (noteForm) {
              noteForm.style.display = 'block';
          }
          
          // Show comment form if it exists
          const commentForm = document.getElementById('comment-form-container');
          if (commentForm) {
              commentForm.style.display = 'block';
          }
      } else {
          // Reset button to show sign in
          authBtn.textContent = 'Sign In';
          authBtn.classList.remove('logged-in');
          
          // Hide note form if it exists
          const noteForm = document.getElementById('note-form-container');
          if (noteForm) {
              noteForm.style.display = 'none';
          }
          
          // Update comment form if it exists
          const commentForm = document.getElementById('comment-form-container');
          if (commentForm) {
              const textarea = commentForm.querySelector('textarea');
              if (textarea) {
                  textarea.placeholder = 'Please sign in to comment';
                  textarea.disabled = true;
              }
              
              const submitBtn = commentForm.querySelector('button[type="submit"]');
              if (submitBtn) {
                  submitBtn.disabled = true;
              }
          }
      }
  }
}

/**
* Setup mobile menu for responsive design
*/
function setupMobileMenu() {
  const nav = document.querySelector('.main-nav');
  
  // Create mobile menu button if it doesn't exist
  if (!document.querySelector('.mobile-menu-btn') && window.innerWidth <= 768) {
      const mobileBtn = document.createElement('button');
      mobileBtn.className = 'mobile-menu-btn';
      mobileBtn.innerHTML = '☰';
      mobileBtn.setAttribute('aria-label', 'Toggle navigation menu');
      
      // Insert before nav
      nav.parentNode.insertBefore(mobileBtn, nav);
      
      // Toggle nav on click
      mobileBtn.addEventListener('click', function() {
          nav.classList.toggle('active');
          this.innerHTML = nav.classList.contains('active') ? '✕' : '☰';
      });
      
      // Add mobile class to nav
      nav.classList.add('mobile');
  }
  
  // Handle window resize
  window.addEventListener('resize', function() {
      const mobileBtn = document.querySelector('.mobile-menu-btn');
      
      if (window.innerWidth <= 768) {
          if (!mobileBtn) {
              setupMobileMenu();
          }
          nav.classList.add('mobile');
      } else {
          if (mobileBtn) {
              mobileBtn.remove();
          }
          nav.classList.remove('mobile', 'active');
      }
  });
}

/**
* Apply animations to elements
*/
function applyAnimations() {
  // Get all animated elements
  const elements = document.querySelectorAll('.article-card, .archive-item, .note-item, .search-result-item');
  
  // Create intersection observer for lazy loading animations
  const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
          if (entry.isIntersecting) {
              entry.target.style.opacity = '1';
              entry.target.style.transform = 'translateY(0)';
              observer.unobserve(entry.target);
          }
      });
  }, {
      root: null,
      threshold: 0.1,
      rootMargin: '0px 0px -100px 0px'
  });
  
  // Observe each element
  elements.forEach(element => {
      // Set initial styles
      element.style.opacity = '0';
      element.style.transform = 'translateY(20px)';
      element.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      
      observer.observe(element);
  });
}

/**
* Show a notification message
* @param {string} message - Message to display
* @param {string} type - Notification type (success, error, warning)
* @param {number} duration - Duration in milliseconds
*/
function showNotification(message, type = 'info', duration = 3000) {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.textContent = message;
  
  // Add to document
  document.body.appendChild(notification);
  
  // Show with animation
  setTimeout(() => {
      notification.classList.add('show');
  }, 10);
  
  // Hide after duration
  setTimeout(() => {
      notification.classList.remove('show');
      
      // Remove after animation completes
      setTimeout(() => {
          notification.remove();
      }, 300);
  }, duration);
}

/**
* Format date to readable string
* @param {string} dateString - ISO date string
* @returns {string} Formatted date
*/
function formatDate(dateString) {
  const date = new Date(dateString);
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return date.toLocaleDateString('en-US', options);
}

/**
* Get URL parameters
* @returns {Object} Object with URL parameters
*/
function getUrlParams() {
  const params = {};
  new URLSearchParams(window.location.search).forEach((value, key) => {
      params[key] = value;
  });
  return params;
}

/**
* Helper function to create DOM elements
* @param {string} tag - HTML tag
* @param {Object} attributes - Element attributes
* @param {string|HTMLElement} content - Element content
* @returns {HTMLElement} Created element
*/
function createElement(tag, attributes = {}, content = '') {
  const element = document.createElement(tag);
  
  // Set attributes
  Object.entries(attributes).forEach(([key, value]) => {
      if (key === 'className') {
          element.className = value;
      } else {
          element.setAttribute(key, value);
      }
  });
  
  // Set content
  if (typeof content === 'string') {
      element.innerHTML = content;
  } else if (content instanceof HTMLElement) {
      element.appendChild(content);
  }
  
  return element;
}

// Add to window for use in other scripts
window.irinfive = {
  isLoggedIn,
  currentUser,
  openModal,
  closeModal,
  showNotification,
  formatDate,
  getUrlParams,
  createElement
};