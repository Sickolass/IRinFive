/**
 * Irinfive - Comments JavaScript
 * Handles comment functionality (listing, creation, interactions)
 */

// Sample comment data (this will come from your API in production)
const SAMPLE_COMMENTS = [
    {
        id: 'comment1',
        postSlug: 'the-future-of-ai',
        content: 'This is a fascinating analysis of how AI is changing international relations. I\'m particularly concerned about autonomous weapons systems and the lack of international consensus on their regulation.',
        authorName: 'Thomas Wilson',
        authorImage: 'images/placeholder.jpg',
        date: '2025-03-04',
        likes: 5,
        parentId: null,
        replies: [
            {
                id: 'comment2',
                postSlug: 'the-future-of-ai',
                content: 'You raise an important point, Thomas. The challenge with regulating autonomous weapons lies in balancing security interests with ethical considerations. Several diplomatic initiatives are underway, but progress has been slow.',
                authorName: 'Dr. Jane Smith',
                authorImage: 'images/placeholder.jpg',
                date: '2025-03-04',
                likes: 3,
                parentId: 'comment1'
            }
        ]
    },
    {
        id: 'comment3',
        postSlug: 'the-future-of-ai',
        content: 'I appreciate how this article addresses the economic implications of AI development alongside security concerns. The potential for AI to exacerbate global inequalities deserves more attention in policy discussions.',
        authorName: 'Sarah Johnson',
        authorImage: 'images/placeholder.jpg',
        date: '2025-03-03',
        likes: 4,
        parentId: null,
        replies: []
    },
    {
        id: 'comment4',
        postSlug: 'cybersecurity-challenges',
        content: 'The section on quantum computing threats to current encryption standards was particularly enlightening. It seems like we\'re in a race against time to develop post-quantum cryptography before these theoretical attacks become practical.',
        authorName: 'Michael Rodriguez',
        authorImage: 'images/placeholder.jpg',
        date: '2025-03-01',
        likes: 2,
        parentId: null,
        replies: []
    }
];

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize comments functionality
    initComments();
    
    console.log('Irinfive comments.js initialized');
});

/**
 * Initialize comments functionality
 */
function initComments() {
    // Get current post slug
    const postSlug = window.irinfive?.getUrlParams()?.slug;
    
    if (postSlug) {
        // Check if comments section exists
        const commentsSection = document.getElementById('comments');
        
        if (commentsSection) {
            // Load comments
            loadComments(postSlug);
            
            // Initialize comment form
            initCommentForm(postSlug);
        }
    }
}

/**
 * Load comments for a post
 * @param {string} postSlug - Post slug
 * @param {number} page - Page number for pagination
 * @param {boolean} append - Whether to append or replace comments
 */
function loadComments(postSlug, page = 1, append = false) {
    const commentsList = document.getElementById('comments-list');
    
    if (!commentsList) return;
    
    // In production, you would fetch from API
    // For demo, filter the sample data
    const topLevelComments = SAMPLE_COMMENTS.filter(comment => 
        comment.postSlug === postSlug && !comment.parentId
    );
    
    // Show loading state if not appending
    if (!append) {
        commentsList.innerHTML = '<div class="loading">Loading comments...</div>';
    }
    
    // Simulate API delay
    setTimeout(() => {
        // Clear loading state if not appending
        if (!append) {
            commentsList.innerHTML = '';
        }
        
        // If no comments, show message
        if (topLevelComments.length === 0 && !append) {
            commentsList.innerHTML = '<div class="no-comments">No comments yet. Be the first to comment!</div>';
            return;
        }
        
        // Sort comments by date (newest first)
        topLevelComments.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        // Append comments
        topLevelComments.forEach(comment => {
            const commentElement = createCommentElement(comment);
            commentsList.appendChild(commentElement);
        });
        
        // Update comments count
        updateCommentsCount(topLevelComments.length);
        
        // Hide "Load More" button when no more comments
        const loadMoreBtn = document.getElementById('load-more-comments');
        if (loadMoreBtn) {
            // In production, you would check if there are more pages
            loadMoreBtn.style.display = page >= 2 ? 'none' : 'block';
        }
        
        // Initialize comment interactions
        setupCommentInteractions();
    }, 500);
}

/**
 * Create a comment element
 * @param {Object} comment - Comment data
 * @returns {HTMLElement} Comment element
 */
function createCommentElement(comment) {
    const { id, content, authorName, authorImage, date, likes, replies } = comment;
    
    // Create comment wrapper
    const commentElement = document.createElement('div');
    commentElement.className = 'comment';
    commentElement.setAttribute('data-id', id);
    
    // Comment header
    const header = document.createElement('div');
    header.className = 'comment-header';
    header.innerHTML = `
        <div class="comment-avatar">
            <img src="${authorImage}" alt="${authorName}">
        </div>
        <div class="comment-author">
            <h4>${authorName}</h4>
            <div class="comment-date">${window.irinfive?.formatDate(date) || date}</div>
        </div>
    `;
    commentElement.appendChild(header);
    
    // Comment content
    const commentContent = document.createElement('div');
    commentContent.className = 'comment-content';
    commentContent.innerHTML = `<p>${content}</p>`;
    commentElement.appendChild(commentContent);
    
    // Comment actions
    const actions = document.createElement('div');
    actions.className = 'comment-actions';
    actions.innerHTML = `
        <button class="comment-reply-btn" data-id="${id}">Reply</button>
        <button class="comment-like-btn" data-id="${id}">
            <span class="like-count">${likes}</span> Like
        </button>
    `;
    commentElement.appendChild(actions);
    
    // Add replies if any
    if (replies && replies.length > 0) {
        const repliesContainer = document.createElement('div');
        repliesContainer.className = 'comment-replies';
        
        replies.forEach(reply => {
            const replyElement = createCommentElement(reply);
            repliesContainer.appendChild(replyElement);
        });
        
        commentElement.appendChild(repliesContainer);
    }
    
    return commentElement;
}

/**
 * Update comments count display
 * @param {number} count - Comments count
 */
function updateCommentsCount(count) {
    const commentsCount = document.getElementById('comments-count');
    
    if (commentsCount) {
        commentsCount.textContent = `${count} Comments`;
    }
}

/**
 * Initialize comment form
 * @param {string} postSlug - Post slug
 */
function initCommentForm(postSlug) {
    const form = document.getElementById('comment-form');
    
    if (!form) return;
    
    // Set post slug
    form.setAttribute('data-post-slug', postSlug);
    
    // Check if user is logged in
    const textarea = form.querySelector('textarea');
    const submitBtn = form.querySelector('button[type="submit"]');
    
    if (textarea && submitBtn) {
        if (!window.irinfive?.isLoggedIn) {
            // Disable form for non-logged in users
            textarea.disabled = true;
            textarea.placeholder = 'Please sign in to comment';
            submitBtn.disabled = true;
        } else {
            // Enable form for logged in users
            textarea.disabled = false;
            textarea.placeholder = 'Add a comment...';
            submitBtn.disabled = false;
        }
    }
    
    // Handle form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Check if user is logged in
        if (!window.irinfive?.isLoggedIn) {
            window.irinfive?.showNotification('Please sign in to comment', 'error');
            return;
        }
        
        // Get comment content
        const content = textarea.value.trim();
        
        if (!content) {
            window.irinfive?.showNotification('Please enter a comment', 'error');
            return;
        }
        
        // Get parent ID if replying
        const parentId = form.getAttribute('data-parent-id') || null;
        
        // Submit comment
        submitComment(postSlug, content, parentId);
    });
}

/**
 * Submit a new comment
 * @param {string} postSlug - Post slug
 * @param {string} content - Comment content
 * @param {string|null} parentId - Parent comment ID if replying
 */
function submitComment(postSlug, content, parentId = null) {
    // Check if user is logged in
    if (!window.irinfive?.isLoggedIn || !window.irinfive?.currentUser) {
        window.irinfive?.showNotification('Please sign in to comment', 'error');
        return;
    }
    
    // Show loading state
    const form = document.getElementById('comment-form');
    const submitBtn = form.querySelector('button[type="submit"]');
    const textarea = form.querySelector('textarea');
    
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Posting...';
    }
    
    // Simulate API delay
    setTimeout(() => {
        // Create new comment object
        const newComment = {
            id: 'comment' + Date.now(),
            postSlug: postSlug,
            content: content,
            authorName: window.irinfive.currentUser.name,
            authorImage: window.irinfive.currentUser.avatar || 'images/placeholder.jpg',
            date: new Date().toISOString(),
            likes: 0,
            parentId: parentId,
            replies: []
        };
        
        // Add to page
        if (parentId) {
            // Add as reply
            const parentComment = document.querySelector(`.comment[data-id="${parentId}"]`);
            
            if (parentComment) {
                // Get or create replies container
                let repliesContainer = parentComment.querySelector('.comment-replies');
                
                if (!repliesContainer) {
                    repliesContainer = document.createElement('div');
                    repliesContainer.className = 'comment-replies';
                    parentComment.appendChild(repliesContainer);
                }
                
                // Add reply
                const replyElement = createCommentElement(newComment);
                repliesContainer.appendChild(replyElement);
                
                // Reset reply form
                form.removeAttribute('data-parent-id');
                const replyForm = document.querySelector('.reply-form-container');
                if (replyForm) {
                    replyForm.remove();
                }
            }
        } else {
            // Add as top-level comment
            const commentsList = document.getElementById('comments-list');
            
            if (commentsList) {
                // Remove no comments message if present
                const noComments = commentsList.querySelector('.no-comments');
                if (noComments) {
                    noComments.remove();
                }
                
                // Add comment at the beginning
                const commentElement = createCommentElement(newComment);
                
                if (commentsList.firstChild) {
                    commentsList.insertBefore(commentElement, commentsList.firstChild);
                } else {
                    commentsList.appendChild(commentElement);
                }
                
                // Update comments count
                const commentsCount = document.getElementById('comments-count');
                if (commentsCount) {
                    const currentCount = parseInt(commentsCount.textContent);
                    updateCommentsCount(isNaN(currentCount) ? 1 : currentCount + 1);
                }
            }
        }
        
        // Reset form
        if (textarea) {
            textarea.value = '';
        }
        
        // Reset button
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Post Comment';
        }
        
        // Setup interactions for new comments
        setupCommentInteractions();
        
        // Show success message
        window.irinfive?.showNotification('Comment posted successfully!', 'success');
    }, 1000);
}

/**
 * Setup comment interaction handlers
 */
function setupCommentInteractions() {
    // Like buttons
    const likeButtons = document.querySelectorAll('.comment-like-btn');
    
    likeButtons.forEach(button => {
        // Remove existing event listeners
        const newButton = button.cloneNode(true);
        button.parentNode.replaceChild(newButton, button);
        
        newButton.addEventListener('click', function() {
            toggleCommentLike(this);
        });
    });
    
    // Reply buttons
    const replyButtons = document.querySelectorAll('.comment-reply-btn');
    
    replyButtons.forEach(button => {
        // Remove existing event listeners
        const newButton = button.cloneNode(true);
        button.parentNode.replaceChild(newButton, button);
        
        newButton.addEventListener('click', function() {
            showReplyForm(this.getAttribute('data-id'));
        });
    });
}

/**
 * Toggle like on a comment
 * @param {HTMLElement} button - Like button element
 */
function toggleCommentLike(button) {
    // Check if user is logged in
    if (!window.irinfive?.isLoggedIn) {
        // Show auth modal
        const authModal = document.getElementById('auth-modal');
        window.irinfive?.openModal(authModal);
        window.irinfive?.showNotification('Please sign in to like comments', 'info');
        return;
    }
    
    // Toggle liked state
    const isLiked = button.classList.contains('liked');
    const countElement = button.querySelector('.like-count');
    const currentCount = parseInt(countElement.textContent);
    
    if (isLiked) {
        // Unlike
        button.classList.remove('liked');
        countElement.textContent = currentCount - 1;
    } else {
        // Like
        button.classList.add('liked');
        countElement.textContent = currentCount + 1;
    }
    
    // In production, you would call an API
    const commentId = button.getAttribute('data-id');
    console.log(`${isLiked ? 'Unlike' : 'Like'} comment: ${commentId}`);
}

/**
 * Show reply form for a comment
 * @param {string} commentId - Comment ID
 */
function showReplyForm(commentId) {
    // Check if user is logged in
    if (!window.irinfive?.isLoggedIn) {
        // Show auth modal
        const authModal = document.getElementById('auth-modal');
        window.irinfive?.openModal(authModal);
        window.irinfive?.showNotification('Please sign in to reply to comments', 'info');
        return;
    }
    
    // Get comment element
    const commentElement = document.querySelector(`.comment[data-id="${commentId}"]`);
    
    if (!commentElement) return;
    
    // Check if reply form already exists
    const existingForm = document.querySelector('.reply-form-container');
    if (existingForm) {
        existingForm.remove();
    }
    
    // Create reply form
    const replyForm = document.createElement('div');
    replyForm.className = 'reply-form-container';
    replyForm.innerHTML = `
        <form class="comment-form reply-form">
            <textarea placeholder="Write a reply..."></textarea>
            <div class="reply-form-actions">
                <button type="button" class="cancel-reply-btn">Cancel</button>
                <button type="submit" class="submit-reply-btn">Reply</button>
            </div>
        </form>
    `;
    
    // Add after comment
    commentElement.appendChild(replyForm);
    
    // Focus textarea
    const textarea = replyForm.querySelector('textarea');
    textarea.focus();
    
    // Set parent ID in main form
    const mainForm = document.getElementById('comment-form');
    if (mainForm) {
        mainForm.setAttribute('data-parent-id', commentId);
    }
    
    // Handle cancel button
    const cancelBtn = replyForm.querySelector('.cancel-reply-btn');
    cancelBtn.addEventListener('click', function() {
        replyForm.remove();
        mainForm.removeAttribute('data-parent-id');
    });
    
    // Handle form submission
    const form = replyForm.querySelector('form');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get content
        const content = textarea.value.trim();
        
        if (!content) {
            window.irinfive?.showNotification('Please enter a reply', 'error');
            return;
        }
        
        // Get post slug
        const postSlug = mainForm.getAttribute('data-post-slug');
        
        // Submit reply
        submitComment(postSlug, content, commentId);
    });
}

/**
 * Initialize load more comments button
 */
function initLoadMoreComments() {
    const loadMoreBtn = document.getElementById('load-more-comments');
    
    if (!loadMoreBtn) return;
    
    // Track current page
    let currentPage = 1;
    
    loadMoreBtn.addEventListener('click', function() {
        // Increment page
        currentPage++;
        
        // Get post slug
        const postSlug = document.getElementById('comment-form')?.getAttribute('data-post-slug');
        
        if (!postSlug) return;
        
        // Load more comments
        loadComments(postSlug, currentPage, true);
        
        // Update button text
        this.textContent = 'Loading...';
        this.disabled = true;
        
        // Reset button after loading
        setTimeout(() => {
            this.textContent = 'Load More Comments';
            this.disabled = false;
        }, 1000);
    });
}

// Call initialization function
initLoadMoreComments();