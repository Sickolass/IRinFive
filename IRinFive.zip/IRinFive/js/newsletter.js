/**
 * Irinfive - Newsletter JavaScript
 * Handles newsletter subscription functionality
 */

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize newsletter functionality
    initNewsletter();
    
    console.log('Irinfive newsletter.js initialized');
});

/**
 * Initialize newsletter functionality
 */
function initNewsletter() {
    // Get newsletter form
    const form = document.getElementById('newsletter-form');
    
    if (!form) return;
    
    // Handle form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get email input
        const emailInput = document.getElementById('email');
        
        if (!emailInput) return;
        
        const email = emailInput.value.trim();
        
        // Validate email
        if (!isValidEmail(email)) {
            showNewsletterMessage('Please enter a valid email address.', 'error');
            return;
        }
        
        // Submit subscription
        subscribeToNewsletter(email);
    });
    
    // Check URL parameters for subscription status
    checkSubscriptionStatus();
}

/**
 * Subscribe to newsletter
 * @param {string} email - User's email
 */
function subscribeToNewsletter(email) {
    // Show loading state
    const submitBtn = document.getElementById('subscribe-btn');
    
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Subscribing...';
    }
    
    // In production, you would call an API
    // For demo, simulate API call
    setTimeout(() => {
        // Check if email is already subscribed (for demo)
        const isAlreadySubscribed = false; // In production, this would come from the API
        
        if (isAlreadySubscribed) {
            showNewsletterMessage('You are already subscribed to our newsletter!', 'info');
        } else {
            showNewsletterMessage('Thank you for subscribing! Please check your email to confirm your subscription.', 'success');
            
            // Clear form
            document.getElementById('email').value = '';
        }
        
        // Reset button
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Subscribe';
        }
    }, 1000);
}

/**
 * Show newsletter message
 * @param {string} message - Message text
 * @param {string} type - Message type (success, error, info)
 */
function showNewsletterMessage(message, type = 'info') {
    const messageElement = document.getElementById('newsletter-message');
    
    if (!messageElement) return;
    
    // Set message content and type
    messageElement.textContent = message;
    messageElement.className = `newsletter-message ${type}`;
    
    // Show message
    messageElement.style.display = 'block';
    
    // Clear message after 5 seconds if it's a success message
    if (type === 'success') {
        setTimeout(() => {
            messageElement.style.display = 'none';
        }, 5000);
    }
}

/**
 * Check subscription status from URL parameters
 */
function checkSubscriptionStatus() {
    const urlParams = new URLSearchParams(window.location.search);
    const status = urlParams.get('subscription');
    
    if (status === 'confirmed') {
        showNewsletterMessage('Your subscription has been confirmed. Thank you!', 'success');
    } else if (status === 'cancelled') {
        showNewsletterMessage('Your subscription request has been cancelled.', 'info');
    } else if (status === 'unsubscribed') {
        showNewsletterMessage('You have been unsubscribed. We\'re sorry to see you go!', 'info');
    }
}

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} Is valid email
 */
function isValidEmail(email) {
    // Basic email validation regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}