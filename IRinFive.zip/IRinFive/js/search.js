/**
 * Irinfive - Search JavaScript
 * Handles search functionality
 */

// Sample content data (this will come from your API in production)
// Combining posts and notes for search
const SEARCH_DATA = [
    // Posts
    {
        type: 'article',
        slug: 'the-future-of-ai',
        title: 'The Future of AI and International Relations',
        excerpt: 'How artificial intelligence is reshaping the landscape of global politics and security in the modern era.',
        date: '2025-03-04',
        readingTime: 5,
        topics: ['Technology', 'Security', 'International Relations'],
        content: 'Artificial intelligence is rapidly evolving from a fascinating technological innovation to a transformative force in global politics and security. This article explores how AI is reshaping international relations and what it means for the future of global security.'
    },
    {
        type: 'article',
        slug: 'cybersecurity-challenges',
        title: 'Cybersecurity Challenges in a Connected World',
        excerpt: 'Examining the growing threats to national security in cyberspace and strategies for resilience.',
        date: '2025-02-28',
        readingTime: 7,
        topics: ['Security', 'Technology', 'Cybersecurity'],
        content: 'As our world becomes increasingly connected, cybersecurity threats continue to evolve in sophistication and impact. From state-sponsored attacks to ransomware targeting critical infrastructure, the digital domain has become a central battlefield for national security.'
    },
    {
        type: 'article',
        slug: 'climate-security',
        title: 'Climate Change as a Security Threat',
        excerpt: 'Understanding how climate change impacts global security, resource conflicts, and migration patterns.',
        date: '2025-02-20',
        readingTime: 6,
        topics: ['Climate', 'Security', 'Migration'],
        content: 'Climate change is increasingly recognized as a major security threat, with implications for resource scarcity, conflict, and large-scale migration. This article examines the security dimensions of our changing climate and how they interact with existing geopolitical tensions.'
    },
    // Notes
    {
        type: 'note',
        id: 'note1',
        content: 'Recent developments in quantum computing could significantly impact encryption standards used for securing diplomatic communications. The race is on to develop quantum-resistant encryption methods.',
        authorName: 'Dr. Jane Smith',
        date: '2025-03-04'
    },
    {
        type: 'note',
        id: 'note2',
        content: 'The intersection of climate change and security is becoming increasingly apparent. New research suggests that climate-induced migration could lead to significant geopolitical shifts in the next decade.',
        authorName: 'Professor Robert Lee',
        date: '2025-03-03'
    },
    {
        type: 'note',
        id: 'note3',
        content: 'AI ethics in military applications remains an unresolved challenge. Without clear international frameworks, we risk entering a dangerous autonomous weapons race.',
        authorName: 'Dr. Michael Chen',
        date: '2025-03-02'
    }
];

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize search functionality
    initSearch();
    
    console.log('Irinfive search.js initialized');
});

/**
 * Initialize search functionality
 */
function initSearch() {
    // Get search form
    const searchForm = document.getElementById('search-form');
    
    if (searchForm) {
        // Handle form submission
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get search input
            const searchInput = document.getElementById('search-input');
            
            if (!searchInput) return;
            
            const query = searchInput.value.trim();
            
            if (!query) {
                // Show empty message
                document.getElementById('search-empty-state').style.display = 'block';
                document.getElementById('search-results-list').style.display = 'none';
                document.getElementById('search-pagination').style.display = 'none';
                document.getElementById('search-status').textContent = '';
                return;
            }
            
            // Perform search
            performSearch(query);
        });
        
        // Handle filter changes
        setupSearchFilters();
        
        // Check for search query in URL
        checkUrlForSearch();
    }
}

/**
 * Check URL for search query
 */
function checkUrlForSearch() {
    const urlParams = new URLSearchParams(window.location.search);
    const query = urlParams.get('q');
    
    if (query) {
        // Set input value
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.value = query;
        }
        
        // Perform search
        performSearch(query);
    }
}

/**
 * Setup search filters
 */
function setupSearchFilters() {
    // Get filter elements
    const typeFilters = document.querySelectorAll('input[name="type"]');
    const sortBy = document.getElementById('sort-by');
    
    // Add event listeners
    if (typeFilters.length > 0) {
        typeFilters.forEach(filter => {
            filter.addEventListener('change', function() {
                // Re-run search with current query
                const searchInput = document.getElementById('search-input');
                if (searchInput && searchInput.value.trim()) {
                    performSearch(searchInput.value.trim());
                }
            });
        });
    }
    
    if (sortBy) {
        sortBy.addEventListener('change', function() {
            // Re-run search with current query
            const searchInput = document.getElementById('search-input');
            if (searchInput && searchInput.value.trim()) {
                performSearch(searchInput.value.trim());
            }
        });
    }
}

/**
 * Perform search
 * @param {string} query - Search query
 */
function performSearch(query) {
    // Show loading state
    const searchStatus = document.getElementById('search-status');
    const searchResultsList = document.getElementById('search-results-list');
    const searchEmptyState = document.getElementById('search-empty-state');
    const searchPagination = document.getElementById('search-pagination');
    
    if (searchStatus) {
        searchStatus.textContent = 'Searching...';
    }
    
    if (searchResultsList) {
        searchResultsList.style.display = 'none';
    }
    
    if (searchEmptyState) {
        searchEmptyState.style.display = 'none';
    }
    
    if (searchPagination) {
        searchPagination.style.display = 'none';
    }
    
    // Get filter values
    const includeArticles = document.querySelector('input[name="type"][value="articles"]')?.checked ?? true;
    const includeNotes = document.querySelector('input[name="type"][value="notes"]')?.checked ?? true;
    const sortBy = document.getElementById('sort-by')?.value || 'relevance';
    
    // In production, you would call an API
    // For demo, search local data
    setTimeout(() => {
        const results = searchLocalData(query, includeArticles, includeNotes, sortBy);
        
        // Update URL with search query
        const url = new URL(window.location);
        url.searchParams.set('q', query);
        window.history.pushState({}, '', url);
        
        // Display results
        displaySearchResults(query, results);
    }, 500);
}

/**
 * Search local data
 * @param {string} query - Search query
 * @param {boolean} includeArticles - Whether to include articles
 * @param {boolean} includeNotes - Whether to include notes
 * @param {string} sortBy - Sort method
 * @returns {Array} Search results
 */
function searchLocalData(query, includeArticles, includeNotes, sortBy) {
    // Normalize query
    const normalizedQuery = query.toLowerCase();
    
    // Filter by content type
    let filteredData = SEARCH_DATA.filter(item => {
        if (item.type === 'article' && !includeArticles) return false;
        if (item.type === 'note' && !includeNotes) return false;
        return true;
    });
    
    // Search in content
    const results = filteredData.filter(item => {
        // Create a merged content string based on item type
        let searchableContent = '';
        
        if (item.type === 'article') {
            searchableContent = [
                item.title,
                item.excerpt,
                item.content,
                ...item.topics
            ].join(' ').toLowerCase();
        } else if (item.type === 'note') {
            searchableContent = [
                item.content,
                item.authorName
            ].join(' ').toLowerCase();
        }
        
        return searchableContent.includes(normalizedQuery);
    });
    
    // Sort results
    switch (sortBy) {
        case 'date-desc':
            results.sort((a, b) => new Date(b.date) - new Date(a.date));
            break;
        case 'date-asc':
            results.sort((a, b) => new Date(a.date) - new Date(b.date));
            break;
        case 'relevance':
        default:
            // For relevance, we would typically score matches
            // Simple implementation: title matches are ranked higher
            results.sort((a, b) => {
                const aTitle = a.title?.toLowerCase().includes(normalizedQuery) || false;
                const bTitle = b.title?.toLowerCase().includes(normalizedQuery) || false;
                
                if (aTitle && !bTitle) return -1;
                if (!aTitle && bTitle) return 1;
                
                // If title match is the same, sort by date
                return new Date(b.date) - new Date(a.date);
            });
            break;
    }
    
    return results;
}

/**
 * Display search results
 * @param {string} query - Search query
 * @param {Array} results - Search results
 */
function displaySearchResults(query, results) {
    const searchStatus = document.getElementById('search-status');
    const searchResultsList = document.getElementById('search-results-list');
    const searchEmptyState = document.getElementById('search-empty-state');
    const searchPagination = document.getElementById('search-pagination');
    
    // Update status
    if (searchStatus) {
        searchStatus.textContent = `${results.length} results for "${query}"`;
    }
    
    // Check if results are empty
    if (results.length === 0) {
        if (searchEmptyState) {
            searchEmptyState.innerHTML = `<p>No results found for "${query}". Please try a different search term.</p>`;
            searchEmptyState.style.display = 'block';
        }
        
        if (searchResultsList) {
            searchResultsList.style.display = 'none';
        }
        
        if (searchPagination) {
            searchPagination.style.display = 'none';
        }
        
        return;
    }
    
    // Display results
    if (searchResultsList) {
        // Clear previous results
        searchResultsList.innerHTML = '';
        
        // Add each result
        results.forEach(result => {
            const resultElement = createSearchResultElement(result, query);
            searchResultsList.appendChild(resultElement);
        });
        
        searchResultsList.style.display = 'block';
    }
    
    // Show pagination if needed
    if (searchPagination && results.length > 10) {
        searchPagination.style.display = 'flex';
    } else if (searchPagination) {
        searchPagination.style.display = 'none';
    }
    
    // Hide empty state
    if (searchEmptyState) {
        searchEmptyState.style.display = 'none';
    }
}

/**
 * Create a search result element
 * @param {Object} result - Result data
 * @param {string} query - Search query for highlighting
 * @returns {HTMLElement} Result element
 */
function createSearchResultElement(result, query) {
    const resultElement = document.createElement('div');
    resultElement.className = 'search-result-item';
    
    if (result.type === 'article') {
        // Article result
        resultElement.innerHTML = `
            <span class="result-type article">Article</span>
            <h2 class="result-title">
                <a href="post.html?slug=${result.slug}">${highlightMatch(result.title, query)}</a>
            </h2>
            <div class="result-meta">
                <span class="result-date">${window.irinfive?.formatDate(result.date) || result.date}</span>
                <span class="result-readtime">${result.readingTime} min read</span>
            </div>
            <p class="result-excerpt">
                ${highlightMatch(result.excerpt, query)}
            </p>
            <div class="result-topics">
                ${result.topics.map(topic => `<span class="result-topic">${topic}</span>`).join('')}
            </div>
        `;
    } else if (result.type === 'note') {
        // Note result
        resultElement.innerHTML = `
            <span class="result-type note">Note</span>
            <div class="result-meta">
                <span class="result-author">${result.authorName}</span>
                <span class="result-date">${window.irinfive?.formatDate(result.date) || result.date}</span>
            </div>
            <p class="result-excerpt">
                ${highlightMatch(result.content, query)}
            </p>
        `;
    }
    
    return resultElement;
}

/**
 * Highlight search query matches in text
 * @param {string} text - Text to highlight in
 * @param {string} query - Search query
 * @returns {string} Highlighted text
 */
function highlightMatch(text, query) {
    if (!text || !query) return text || '';
    
    // Escape regex special characters
    const escapedQuery = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    
    // Create regex for case-insensitive global match
    const regex = new RegExp(`(${escapedQuery})`, 'gi');
    
    // Replace with highlighted version
    return text.replace(regex, '<mark>$1</mark>');
}