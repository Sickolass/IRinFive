// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Vanta.js background
    VANTA.DOTS({
      el: "#vanta-background",
      mouseControls: true,
      touchControls: true,
      gyroControls: false,
      minHeight: 200.00,
      minWidth: 200.00,
      scale: 1.00,
      scaleMobile: 1.00,
      color: 0x131f7c,
      color2: 0x12a0ca,
      size: 3.00,
      spacing: 25.00
    });
  });

  // Stop animation when page is not visible to save resources
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
      // Pause animation when tab is not visible
      if (window.vantaEffect) {
        window.vantaEffect.stop();
      }
    } else {
      // Resume animation when tab becomes visible again
      if (window.vantaEffect) {
        window.vantaEffect.restart();
      }
    }
  });
  
  // Store the effect instance for later reference
  window.vantaEffect = VANTA.DOTS({
    // config settings here (same as above)
  });