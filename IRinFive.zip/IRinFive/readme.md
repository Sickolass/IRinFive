# Irinfive Newsletter Site

A modern, responsive newsletter website for international security and global affairs content. This project serves as both a development platform with VS Code Live Server and a production-ready site for Cloudflare Pages deployment.

## Project Overview

This repository contains a complete website for publishing articles, short-form notes, and sending newsletters. It was designed to migrate content from Substack while maintaining full control over the design and functionality.

### Features

- **Article Publishing**: Long-form content with rich formatting
- **Notes System**: Twitter-like short-form content
- **Newsletter Integration**: Email subscription and delivery
- **User Authentication**: Sign in/up with email or social accounts
- **Comments System**: Threaded discussions on articles and notes
- **Search Functionality**: Find content across the site
- **Archive System**: Browse all published content by date and topic
- **Responsive Design**: Works on all device sizes

## Getting Started

### Prerequisites

- [Visual Studio Code](https://code.visualstudio.com/) with [Live Server extension](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer)
- Node.js and npm (for running conversion scripts and deploying to Cloudflare)
- A Cloudflare account (for production deployment)

### Local Development Setup

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/irinfive-website.git
   cd irinfive-website
   ```

2. Open the project in VS Code:
   ```bash
   code .
   ```

3. Install the Live Server extension if you haven't already:
   - Open Extensions view (Ctrl+Shift+X)
   - Search for "Live Server"
   - Install the extension by Ritwick Dey

4. Start the local server:
   - Right-click on `index.html`
   - Select "Open with Live Server"
   - The site will open in your browser at `http://127.0.0.1:5500/`

### Project Structure

```
irinfive-website/
├── index.html              # Homepage
├── about.html              # About page
├── notes.html              # Notes page
├── archive.html            # Archive page
├── post.html               # Single post page template
├── search.html             # Search page
├── newsletter/             # Newsletter subscription pages
│   ├── subscribe.html      # Subscription success page
│   ├── confirmed.html      # Email confirmation success page
│   └── unsubscribed.html   # Unsubscribe confirmation page
├── css/
│   └── style.css           # Main stylesheet
├── js/
│   ├── main.js             # Core functionality
│   ├── posts.js            # Posts and articles handling
│   ├── notes.js            # Notes functionality
│   ├── comments.js         # Comments system
│   ├── newsletter.js       # Newsletter subscription
│   └── search.js           # Search functionality
├── images/                 # Image assets
│   ├── irinfivelogo.png    # Site logo
│   └── ...                 # Other images
└── content/                # Content folder (for Next.js migration)
    ├── posts/              # Markdown post files
    └── notes/              # Notes data
```

## Migrating from Substack

### Export Substack Content

1. Export subscriber list:
   - Log in to your Substack dashboard
   - Go to "Settings" > "Lists"
   - Click "Export" next to your subscriber list
   - Save the CSV file

2. Export posts:
   - Go to "Settings" > "Export"
   - Click "Export posts"
   - Download the ZIP file containing HTML files

3. Extract images:
   ```bash
   # Install dependencies
   npm install cheerio fs path

   # Run the image extraction script
   node scripts/download-images.js
   ```

4. Convert posts to Markdown:
   ```bash
   # Install dependencies
   npm install turndown cheerio

   # Run the conversion script
   node scripts/convert-to-markdown.js
   ```

## Cloudflare Pages Deployment

### Method 1: Direct Upload (Recommended)

1. Install Wrangler CLI:
   ```bash
   npm install -g wrangler
   ```

2. Authenticate with Cloudflare:
   ```bash
   wrangler login
   ```

3. Deploy to Cloudflare Pages:
   ```bash
   wrangler pages publish . --project-name=irinfive
   ```

### Method 2: GitHub Integration

1. Push your code to a GitHub repository
2. In the Cloudflare Dashboard:
   - Go to Pages
   - Click "Create a project"
   - Connect your GitHub account
   - Select your repository
   - Configure build settings (not required for this static site)
   - Deploy

## Next.js Migration

To upgrade this site to a full Next.js application:

1. Create a new Next.js project:
   ```bash
   npx create-next-app@latest irinfive-nextjs
   ```

2. Copy content, design, and functionality:
   - Move `content/` directory to the Next.js project
   - Convert HTML pages to Next.js pages
   - Adapt JavaScript to React components
   - Set up API routes for dynamic functionality

3. Implement server-side features:
   - Database integration with Supabase
   - Authentication with Clerk
   - Newsletter management with ConvertKit

## Customization

### Modifying the Theme

The site uses CSS variables for easy theming. Edit the `:root` section in `css/style.css` to change colors:

```css
:root {
  --primary-color: #080e15;        /* Main background */
  --secondary-color: #10151d;      /* Card backgrounds */
  --accent-color: #3E88F6;         /* Buttons, links, highlights */
  --text-color: #E6EDF3;           /* Main text */
  --text-secondary: #A3B9CC;       /* Secondary text */
  --border-color: #1a222b;         /* Borders */
  --background-light: #02122d;     /* Lighter backgrounds */
  /* ... other variables */
}
```

### Adding Content

#### New Posts
For local development:
1. Create a new post template in `post.html?slug=your-new-post-slug`
2. Add the post data to the `SAMPLE_POSTS` array in `js/posts.js`

For production:
1. Add a new Markdown file in `content/posts/your-new-post-slug.md`
2. Include proper frontmatter (title, date, excerpt, etc.)

#### New Notes
For local development:
1. Add note data to the `SAMPLE_NOTES` array in `js/notes.js`

For production:
1. Notes are stored in the database (Supabase)

## Third-Party Services Integration

### Authentication (Clerk)
- Create a Clerk application: https://dashboard.clerk.dev/
- Get API keys and add to environment
- Update authentication logic in production version

### Database (Supabase)
- Create a Supabase project: https://app.supabase.io/
- Set up tables as defined in the schema
- Configure Row Level Security policies
- Add API keys to environment

### Newsletter (ConvertKit)
- Create a ConvertKit account: https://convertkit.com/
- Set up a form for your site
- Get API key and form ID
- Update newsletter.js with your form details

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Design and layout inspired by modern newsletter platforms
- Icons from various sources, credited in the code
- Sample content for demonstration purposes only