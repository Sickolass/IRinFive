// admin/js/auth.js
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Clerk with restricted permissions
    const clerk = window.Clerk.init({
      // Use your Clerk publishable key
      publishableKey: 'your_clerk_publishable_key'
    });
    
    clerk.addListener(({ user }) => {
      if (user) {
        // Check if user has admin role
        const isAdmin = user.publicMetadata.role === 'admin';
        if (isAdmin) {
          // Show admin interface
          document.getElementById('admin-content').style.display = 'block';
          document.getElementById('login-required').style.display = 'none';
        } else {
          // Show unauthorized message
          document.getElementById('admin-content').style.display = 'none';
          document.getElementById('login-required').style.display = 'block';
          document.getElementById('unauthorized-message').style.display = 'block';
        }
      } else {
        // Show login form
        document.getElementById('admin-content').style.display = 'none';
        document.getElementById('login-required').style.display = 'block';
        document.getElementById('unauthorized-message').style.display = 'none';
      }
    });
  });