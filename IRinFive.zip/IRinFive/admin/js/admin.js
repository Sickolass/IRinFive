// admin/js/admin.js
document.addEventListener('DOMContentLoaded', function() {
    // References to DOM elements
    const contentEditor = document.getElementById('content-editor');
    const contentList = document.getElementById('content-list');
    const contentTitle = document.getElementById('content-title');
    const contentSubtitle = document.getElementById('content-subtitle');
    const contentType = document.getElementById('content-type');
    const contentTopics = document.getElementById('content-topics');
    const contentBody = document.getElementById('content-body');
    const imageUpload = document.getElementById('image-upload');
    const imagePreview = document.getElementById('image-preview');
    const uploadImageBtn = document.getElementById('upload-image-btn');
    const saveDraftBtn = document.getElementById('save-draft-btn');
    const publishBtn = document.getElementById('publish-btn');
    
    // Current editing state
    let currentContentId = null;
    let uploadedImageUrl = null;
    
    // Initialize Supabase client
    const supabaseUrl = 'YOUR_SUPABASE_URL';
    const supabaseKey = 'YOUR_SUPABASE_KEY';
    const supabase = supabase.createClient(supabaseUrl, supabaseKey);
    
    // Load existing content
    loadContent();
    
    // Event listeners
    imageUpload.addEventListener('change', handleImagePreview);
    uploadImageBtn.addEventListener('click', uploadImage);
    saveDraftBtn.addEventListener('click', () => saveContent(true));
    publishBtn.addEventListener('click', () => saveContent(false));
    
    // Content type filter
    document.getElementById('filter-content-type').addEventListener('change', loadContent);
    
    // Search content
    document.getElementById('search-content').addEventListener('input', debounce(loadContent, 300));
    
    // Handle image preview
    function handleImagePreview() {
      const file = imageUpload.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
          imagePreview.src = e.target.result;
        };
        reader.readAsDataURL(file);
      }
    }
    
    // Upload image to Supabase storage
    async function uploadImage() {
      const file = imageUpload.files[0];
      if (!file) {
        showNotification('Please select an image to upload', 'error');
        return;
      }
      
      // Show loading state
      uploadImageBtn.disabled = true;
      uploadImageBtn.textContent = 'Uploading...';
      
      try {
        // Upload to Supabase storage
        const fileName = `${Date.now()}_${file.name}`;
        const { data, error } = await supabase.storage
          .from('content-images')
          .upload(`public/${fileName}`, file);
        
        if (error) throw error;
        
        // Get public URL
        const { publicURL, error: urlError } = supabase.storage
          .from('content-images')
          .getPublicUrl(`public/${fileName}`);
        
        if (urlError) throw urlError;
        
        uploadedImageUrl = publicURL;
        showNotification('Image uploaded successfully', 'success');
      } catch (error) {
        console.error('Error uploading image:', error);
        showNotification('Failed to upload image', 'error');
      } finally {
        // Reset button state
        uploadImageBtn.disabled = false;
        uploadImageBtn.textContent = 'Upload Image';
      }
    }
    
    // Save content (draft or published)
    async function saveContent(isDraft) {
      // Validate fields
      if (!contentTitle.value.trim()) {
        showNotification('Title is required', 'error');
        return;
      }
      
      if (!contentBody.value.trim()) {
        showNotification('Content is required', 'error');
        return;
      }
      
      // Prepare content data
      const contentData = {
        title: contentTitle.value.trim(),
        subtitle: contentSubtitle.value.trim(),
        content: contentBody.value.trim(),
        type: contentType.value,
        topics: contentTopics.value.split(',').map(topic => topic.trim()).filter(Boolean),
        is_draft: isDraft,
        cover_image: uploadedImageUrl,
        updated_at: new Date().toISOString()
      };
      
      // If new content, add creation date
      if (!currentContentId) {
        contentData.created_at = new Date().toISOString();
        
        // Generate slug from title
        contentData.slug = contentTitle.value
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-+|-+$/g, '');
      }
      
      try {
        let result;
        
        if (currentContentId) {
          // Update existing content
          result = await supabase
            .from('content')
            .update(contentData)
            .match({ id: currentContentId });
        } else {
          // Insert new content
          result = await supabase
            .from('content')
            .insert([contentData]);
        }
        
        if (result.error) throw result.error;
        
        // Show success message
        showNotification(
          `Content ${isDraft ? 'saved as draft' : 'published'} successfully`, 
          'success'
        );
        
        // Reset form and reload content list
        resetForm();
        loadContent();
      } catch (error) {
        console.error('Error saving content:', error);
        showNotification('Failed to save content', 'error');
      }
    }
    
    // Load content list
    async function loadContent() {
      const contentType = document.getElementById('filter-content-type').value;
      const searchQuery = document.getElementById('search-content').value.trim();
      
      let query = supabase
        .from('content')
        .select('*')
        .order('created_at', { ascending: false });
      
      // Apply filters
      if (contentType !== 'all') {
        query = query.eq('type', contentType);
      }
      
      if (searchQuery) {
        query = query.or(`title.ilike.%${searchQuery}%,content.ilike.%${searchQuery}%`);
      }
      
      try {
        const { data, error } = await query;
        
        if (error) throw error;
        
        // Update content table
        const tableBody = document.getElementById('content-table-body');
        tableBody.innerHTML = '';
        
        if (data.length === 0) {
          const emptyRow = document.createElement('tr');
          emptyRow.innerHTML = `
            <td colspan="4" style="text-align: center;">No content found</td>
          `;
          tableBody.appendChild(emptyRow);
        } else {
          data.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
              <td>${item.title} ${item.is_draft ? '<span class="draft-badge">Draft</span>' : ''}</td>
              <td>${item.type === 'post' ? 'Article' : 'Note'}</td>
              <td>${formatDate(item.created_at)}</td>
              <td class="action-buttons">
                <button class="action-button edit" data-id="${item.id}">Edit</button>
                <button class="action-button view" data-slug="${item.slug}">View</button>
                <button class="action-button delete" data-id="${item.id}">Delete</button>
              </td>
            `;
            tableBody.appendChild(row);
          });
          
          // Add event listeners to action buttons
          document.querySelectorAll('.action-button.edit').forEach(button => {
            button.addEventListener('click', () => editContent(button.dataset.id));
          });
          
          document.querySelectorAll('.action-button.view').forEach(button => {
            button.addEventListener('click', () => {
              window.open(`../post.html?slug=${button.dataset.slug}`, '_blank');
            });
          });
          
          document.querySelectorAll('.action-button.delete').forEach(button => {
            button.addEventListener('click', () => deleteContent(button.dataset.id));
          });
        }
      } catch (error) {
        console.error('Error loading content:', error);
        showNotification('Failed to load content', 'error');
      }
    }
    
    // Edit content
    async function editContent(id) {
      try {
        const { data, error } = await supabase
          .from('content')
          .select('*')
          .eq('id', id)
          .single();
        
        if (error) throw error;
        
        // Populate form with content data
        currentContentId = data.id;
        contentTitle.value = data.title || '';
        contentSubtitle.value = data.subtitle || '';
        contentType.value = data.type || 'post';
        contentTopics.value = (data.topics || []).join(', ');
        contentBody.value = data.content || '';
        
        if (data.cover_image) {
          imagePreview.src = data.cover_image;
          uploadedImageUrl = data.cover_image;
        } else {
          imagePreview.src = '../images/placeholder.jpg';
          uploadedImageUrl = null;
        }
        
        // Update button text
        saveDraftBtn.textContent = 'Update Draft';
        publishBtn.textContent = 'Update & Publish';
        
        // Scroll to editor
        contentEditor.scrollIntoView({ behavior: 'smooth' });
      } catch (error) {
        console.error('Error loading content for edit:', error);
        showNotification('Failed to load content', 'error');
      }
    }
    
    // Delete content
    async function deleteContent(id) {
      if (!confirm('Are you sure you want to delete this content? This action cannot be undone.')) {
        return;
      }
      
      try {
        const { error } = await supabase
          .from('content')
          .delete()
          .match({ id });
        
        if (error) throw error;
        
        showNotification('Content deleted successfully', 'success');
        loadContent();
        
        // If currently editing this content, reset form
        if (currentContentId === id) {
          resetForm();
        }
      } catch (error) {
        console.error('Error deleting content:', error);
        showNotification('Failed to delete content', 'error');
      }
    }
    
    // Reset form
    function resetForm() {
      currentContentId = null;
      contentTitle.value = '';
      contentSubtitle.value = '';
      contentType.value = 'post';
      contentTopics.value = '';
      contentBody.value = '';
      imagePreview.src = '../images/placeholder.jpg';
      uploadedImageUrl = null;
      imageUpload.value = '';
      
      // Reset button text
      saveDraftBtn.textContent = 'Save Draft';
      publishBtn.textContent = 'Publish';
    }
    
    // Show notification
    function showNotification(message, type = 'info') {
      // You can implement this using your existing notification system
      if (window.irinfive?.showNotification) {
        window.irinfive.showNotification(message, type);
      } else {
        alert(message);
      }
    }
    
    // Format date
    function formatDate(dateString) {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    }
    
    // Debounce function for search input
    function debounce(func, delay) {
      let timeoutId;
      return function() {
        const context = this;
        const args = arguments;
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          func.apply(context, args);
        }, delay);
      };
    }
  });