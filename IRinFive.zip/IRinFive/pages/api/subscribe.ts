// pages/api/subscribe.ts
import type { NextApiRequest, NextApiResponse } from 'next';

type ResponseData = {
  success: boolean;
  message: string;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<ResponseData>
) {
  // Only allow POST
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      message: 'Method not allowed'
    });
  }

  // Get data from request body
  const { email, firstName } = req.body;

  // Validate email
  if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
    return res.status(400).json({
      success: false,
      message: 'Valid email address is required'
    });
  }

  try {
    // ConvertKit API credentials from environment variables
    const FORM_ID = process.env.CONVERTKIT_FORM_ID;
    const API_KEY = process.env.CONVERTKIT_API_KEY;

    if (!FORM_ID || !API_KEY) {
      console.error('ConvertKit credentials missing');
      return res.status(500).json({
        success: false,
        message: 'Server configuration error'
      });
    }

    // Prepare subscriber data
    const data = {
      email,
      first_name: firstName
    };

    // Submit to ConvertKit API
    const response = await fetch(
      `https://api.convertkit.com/v3/forms/${FORM_ID}/subscribe`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          api_key: API_KEY,
          ...data
        }),
      }
    );

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || 'Error subscribing to newsletter');
    }

    // Success response
    return res.status(200).json({
      success: true,
      message: 'Successfully subscribed to the newsletter!'
    });
  } catch (error) {
    console.error('Newsletter subscription error:', error);
    return res.status(500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Failed to subscribe'
    });
  }
}