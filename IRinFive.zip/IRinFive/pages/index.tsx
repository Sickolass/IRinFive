// pages/index.tsx
import { GetStaticProps } from 'next';
import Head from 'next/head';
import Link from 'next/link';
import Image from 'next/image';
import Layout from '../components/layout';
import Container from '../components/container';
import { getAllPosts, PostMeta } from '../lib/posts';
import DateFormatter from '../components/date-formatter';

export default function Home({ posts }: { posts: PostMeta[] }) {
  return (
    <Layout>
      <Head>
        <title>IRinFive</title>
        <meta
          name="description"
          content="Exploring the intersection of technology, security, and international relations."
        />
      </Head>

      <Container>
        <section className="hero-section">
          <h1>IRinFive</h1>
          <p className="subtitle">
            Exploring the intersection of technology, security, and international relations.
          </p>
        </section>

        <section className="latest-posts">
          <h2>Latest Articles</h2>
          <div className="posts-grid">
            {posts.map((post) => (
              <article key={post.slug} className="post-card">
                {post.coverImage && (
                  <Link href={`/posts/${post.slug}`}>
                    <div className="post-image">
                      <Image
                        src={post.coverImage}
                        alt={post.title}
                        width={600}
                        height={340}
                        layout="responsive"
                      />
                    </div>
                  </Link>
                )}
                <div className="post-content">
                  <Link href={`/posts/${post.slug}`}>
                    <h3>{post.title}</h3>
                  </Link>
                  <p className="post-excerpt">{post.excerpt}</p>
                  <div className="post-meta">
                    <DateFormatter dateString={post.date} />
                    <span>{post.readingTime} min read</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>
      </Container>
    </Layout>
  );
}

export const getStaticProps: GetStaticProps = async () => {
  const posts = getAllPosts([
    'slug',
    'title',
    'date',
    'excerpt',
    'coverImage',
    'readingTime',
  ]);

  return {
    props: { posts: posts.slice(0, 6) },
  };
};