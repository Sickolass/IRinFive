// pages/posts/[slug].tsx
import { GetStaticProps, GetStaticPaths } from 'next';
import Head from 'next/head';
import Link from 'next/link';
import Image from 'next/image';
import { getPostBySlug, getAllPosts, markdownToHtml, Post as PostType } from '@/lib/posts';
import Layout from '@/components/layout';
import DateFormatter from '@/components/date-formatter';
import Container from '@/components/container';
import NewsletterForm from '@/components/newsletter-form';

export default function Post({ post }: { post: PostType }) {
  return (
    <Layout>
      <Head>
        <title>{post.title} | IRinFive</title>
        <meta name="description" content={post.excerpt} />
        <meta property="og:image" content={post.coverImage} />
      </Head>
      
      <article className="post-container">
        <header className="post-header">
          <Container>
            <h1 className="post-title">{post.title}</h1>
            {post.subtitle && <h2 className="post-subtitle">{post.subtitle}</h2>}
            
            <div className="post-meta">
              <span className="post-date">
                <DateFormatter dateString={post.date} />
              </span>
              <span className="post-readtime">{post.readingTime} min read</span>
              {post.topics && post.topics.length > 0 && (
                <span className="post-topic">{post.topics[0]}</span>
              )}
            </div>
            
            {post.coverImage && (
              <div className="post-cover">
                <Image 
                  src={post.coverImage}
                  alt={post.title}
                  width={1200}
                  height={630}
                  layout="responsive"
                  priority
                />
              </div>
            )}
          </Container>
        </header>
        
        <Container>
          <div 
            className="post-content"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
          
          <footer className="post-footer">
            {post.topics && post.topics.length > 0 && (
              <div className="post-tags">
                {post.topics.map(topic => (
                  <Link 
                    href={`/topics/${topic.toLowerCase()}`}
                    key={topic}
                    className="post-tag"
                  >
                    {topic}
                  </Link>
                ))}
              </div>
            )}
            
            <div className="post-author">
              <div className="author-bio">
                <h3>{post.author}</h3>
              </div>
            </div>
            
            <div className="post-actions">
              <div className="post-share">
                <span>Share:</span>
                <a 
                  href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(post.title)}&url=${encodeURIComponent(`https://yoursite.com/posts/${post.slug}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="share-btn twitter"
                >
                  Twitter
                </a>
                <a 
                  href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(`https://yoursite.com/posts/${post.slug}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="share-btn linkedin"
                >
                  LinkedIn
                </a>
              </div>
            </div>
          </footer>
        </Container>
      </article>
      
      <section className="newsletter-section">
        <Container>
          <div className="newsletter-container">
            <h2>Join Our Community</h2>
            <p>Subscribe to receive our latest articles and updates directly in your inbox.</p>
            <NewsletterForm />
          </div>
        </Container>
      </section>
    </Layout>
  );
}

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const post = getPostBySlug(params?.slug as string, [
    'slug',
    'title',
    'subtitle',
    'date',
    'coverImage',
    'topics',
    'content',
    'excerpt',
    'readingTime',
    'author',
  ]);
  
  const content = await markdownToHtml(post.content || '');
  
  return {
    props: {
      post: {
        ...post,
        content,
      },
    },
  };
};

export const getStaticPaths: GetStaticPaths = async () => {
  const posts = getAllPosts(['slug']);
  
  return {
    paths: posts.map((post) => {
      return {
        params: {
          slug: post.slug,
        },
      };
    }),
    fallback: 'blocking',
  };
};