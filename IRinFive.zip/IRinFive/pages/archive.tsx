// pages/archive.tsx
import { GetStaticProps } from 'next';
import Head from 'next/head';
import Link from 'next/link';
import Layout from '../components/layout';
import Container from '../components/container';
import { getAllPosts, PostMeta } from '../lib/posts';
import DateFormatter from '../components/date-formatter';

export default function Archive({ posts }: { posts: PostMeta[] }) {
  return (
    <Layout>
      <Head>
        <title>Archive | IRinFive</title>
        <meta
          name="description"
          content="Browse all articles from IRinFive."
        />
      </Head>

      <Container>
        <h1>Archive</h1>
        <p>A complete collection of all articles published on IRinFive.</p>
        
        <div className="archive-list">
          {posts.map((post) => (
            <article key={post.slug} className="archive-item">
              <div className="archive-date">
                <DateFormatter dateString={post.date} />
              </div>
              <h2 className="archive-title">
                <Link href={`/posts/${post.slug}`}>
                  {post.title}
                </Link>
              </h2>
              <div className="archive-meta">
                <span className="archive-topic">
                  {post.topics && post.topics.length > 0 ? post.topics[0] : 'General'}
                </span>
                <span className="archive-readtime">{post.readingTime} min read</span>
              </div>
            </article>
          ))}
        </div>
      </Container>
    </Layout>
  );
}

export const getStaticProps: GetStaticProps = async () => {
  const posts = getAllPosts([
    'slug',
    'title',
    'date',
    'excerpt',
    'coverImage',
    'readingTime',
    'topics',
  ]);

  return {
    props: { posts },
  };
};