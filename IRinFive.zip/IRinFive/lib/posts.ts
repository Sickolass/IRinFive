// lib/posts.ts - Next.js utility for loading posts from the filesystem

import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { remark } from 'remark';
import html from 'remark-html';

// Path to markdown content
const postsDirectory = path.join(process.cwd(), 'content/posts');

// Post types
export interface PostMeta {
  slug: string;
  title: string;
  subtitle?: string;
  date: string;
  coverImage?: string;
  topics: string[];
  readingTime: number;
  author: string;
  excerpt: string;
}

export interface Post extends PostMeta {
  content: string;
}

/**
 * Get all post slugs
 */
export function getPostSlugs() {
  if (!fs.existsSync(postsDirectory)) {
    return [];
  }
  return fs.readdirSync(postsDirectory)
    .filter(file => file.endsWith('.md'))
    .map(file => file.replace(/\.md$/, ''));
}

/**
 * Get post data by slug
 */
export function getPostBySlug(slug: string, fields: string[] = []): Partial<Post> {
  const fullPath = path.join(postsDirectory, `${slug}.md`);
  
  if (!fs.existsSync(fullPath)) {
    return {};
  }
  
  const fileContents = fs.readFileSync(fullPath, 'utf8');
  const { data, content } = matter(fileContents);
  
  const post: Partial<Post> = {};
  
  // Ensure only the requested fields are included
  fields.forEach((field) => {
    if (field === 'slug') {
      post.slug = slug;
    }
    if (field === 'content' && content) {
      post.content = content;
    }
    
    if (data[field] !== undefined) {
      (post as any)[field] = data[field];
    }
  });
  
  return post;
}

/**
 * Get all posts metadata, sorted by date
 */
export function getAllPosts(fields: string[] = [
  'slug', 'title', 'date', 'coverImage', 'excerpt', 'topics', 'readingTime', 'author'
]): PostMeta[] {
  const slugs = getPostSlugs();
  
  const posts = slugs
    .map(slug => getPostBySlug(slug, fields) as PostMeta)
    .filter(post => post.title) // Filter out any empty posts
    // Sort posts by date in descending order
    .sort((post1, post2) => (post1.date > post2.date ? -1 : 1));
    
  return posts;
}

/**
 * Convert markdown to HTML
 */
export async function markdownToHtml(markdown: string) {
  try {
    const result = await remark()
      .use(html, { sanitize: false })
      .process(markdown);
    return result.toString();
  } catch (error) {
    console.error('Error converting markdown to HTML:', error);
    return '';
  }
}

/**
 * Get posts by topic
 */
export function getPostsByTopic(topic: string, fields: string[] = [
  'slug', 'title', 'date', 'coverImage', 'excerpt', 'topics', 'readingTime', 'author'
]): PostMeta[] {
  const allPosts = getAllPosts(fields);
  return allPosts.filter(post => 
    post.topics && post.topics.some(t => t.toLowerCase() === topic.toLowerCase())
  );
}

/**
 * Get all unique topics
 */
export function getAllTopics(): string[] {
  const allPosts = getAllPosts(['topics']);
  const topicsSet = new Set<string>();
  
  allPosts.forEach(post => {
    if (post.topics) {
      post.topics.forEach(topic => {
        topicsSet.add(topic);
      });
    }
  });
  
  return Array.from(topicsSet).sort();
}