// lib/newsletter.ts - ConvertKit Integration for Next.js

export interface NewsletterResponse {
    success: boolean;
    message: string;
  }
  
  export interface ConvertKitSubscriberData {
    email: string;
    first_name?: string;
    tags?: number[];
  }
  
  /**
   * Subscribe a user to your ConvertKit newsletter
   * 
   * @param email User's email address
   * @param firstName User's first name (optional)
   * @param tags Array of tag IDs to apply to the subscriber
   * @returns Response with success/failure
   */
  export async function subscribeToNewsletter(
    email: string,
    firstName?: string,
    tags?: number[]
  ): Promise<NewsletterResponse> {
    if (!process.env.CONVERTKIT_API_KEY || !process.env.CONVERTKIT_FORM_ID) {
      console.error('Missing ConvertKit credentials');
      return {
        success: false,
        message: 'Newsletter configuration error'
      };
    }
  
    const CONVERTKIT_API = 'https://api.convertkit.com/v3';
    const FORM_ID = process.env.CONVERTKIT_FORM_ID;
    const API_KEY = process.env.CONVERTKIT_API_KEY;
  
    try {
      // Prepare subscriber data
      const data: ConvertKitSubscriberData = { email };
      if (firstName) data.first_name = firstName;
      if (tags && tags.length > 0) data.tags = tags;
  
      // Make API request to ConvertKit
      const response = await fetch(
        `${CONVERTKIT_API}/forms/${FORM_ID}/subscribe`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            api_key: API_KEY,
            ...data
          }),
        }
      );
  
      const result = await response.json();
  
      if (!response.ok) {
        throw new Error(result.message || 'Failed to subscribe');
      }
  
      return {
        success: true,
        message: 'Successfully subscribed to the newsletter!'
      };
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Failed to subscribe'
      };
    }
  }
  
  /**
   * Create a newsletter subscription API endpoint for your Next.js app
   * Place this in /pages/api/subscribe.ts
   */
  /*
  import type { NextApiRequest, NextApiResponse } from 'next';
  import { subscribeToNewsletter, NewsletterResponse } from '@/lib/newsletter';
  
  export default async function handler(
    req: NextApiRequest,
    res: NextApiResponse<NewsletterResponse>
  ) {
    // Only allow POST method
    if (req.method !== 'POST') {
      return res.status(405).json({
        success: false,
        message: 'Method not allowed'
      });
    }
  
    try {
      const { email, firstName } = req.body;
  
      // Validate email
      if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
        return res.status(400).json({
          success: false,
          message: 'Valid email is required'
        });
      }
  
      // Subscribe user to newsletter
      const result = await subscribeToNewsletter(email, firstName);
      
      if (result.success) {
        return res.status(200).json(result);
      } else {
        return res.status(400).json(result);
      }
      
    } catch (error) {
      console.error('Newsletter API error:', error);
      return res.status(500).json({
        success: false,
        message: 'Server error, please try again later'
      });
    }
  }
  */